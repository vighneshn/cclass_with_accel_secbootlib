// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VmkTbSoc.h for the primary calling header

#include "VmkTbSoc.h"
#include "VmkTbSoc__Syms.h"

VL_INLINE_OPT void VmkTbSoc::_sequent__TOP__9(VmkTbSoc__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VmkTbSoc::_sequent__TOP__9\n"); );
    VmkTbSoc* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle 
        = vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle;
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_read_synced_response_from_dm) 
             & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dEnqToggle) 
                != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle)))) {
            vlTOPp->__Vdly__mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle 
                = (1U & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle)));
        }
    } else {
        vlTOPp->__Vdly__mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle = 0U;
    }
}

VL_INLINE_OPT void VmkTbSoc::_sequent__TOP__10(VmkTbSoc__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VmkTbSoc::_sequent__TOP__10\n"); );
    VmkTbSoc* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->RST_N) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_read_synced_response_from_dm) 
                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dEnqToggle) 
                            == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle))))) {
            VL_WRITEF("Warning: SyncFIFO1: %NmkTbSoc.soc.sync_response_from_dm.error_checks2 -- Dequeuing from an empty full fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_DEQ)))) {
            VL_WRITEF("Warning: FIFO1: %NmkTbSoc.soc.jtag_tap.response_from_DM.error_checks -- Dequeuing from empty fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
        if (VL_UNLIKELY((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg) 
                          & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_ENQ)) 
                         & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_DEQ))))) {
            VL_WRITEF("Warning: FIFO1: %NmkTbSoc.soc.jtag_tap.response_from_DM.error_checks -- Enqueuing to a full fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg)) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_DEQ)))) {
            VL_WRITEF("Warning: FIFO1: %NmkTbSoc.soc.jtag_tap.request_to_DM.error_checks -- Dequeuing from empty fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
        if (VL_UNLIKELY((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg) 
                          & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_ENQ)) 
                         & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_DEQ))))) {
            VL_WRITEF("Warning: FIFO1: %NmkTbSoc.soc.jtag_tap.request_to_DM.error_checks -- Enqueuing to a full fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_connect_tap_request_to_syncfifo) 
                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_request_to_dm__DOT__sEnqToggle) 
                            != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_request_to_dm__DOT__sDeqToggle))))) {
            VL_WRITEF("Warning: SyncFIFO1: %NmkTbSoc.soc.sync_request_to_dm.error_checks1 -- Enqueuing to a full fifo\n",
                      vlSymsp->name());
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_ENQ) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_D_OUT 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__syncFIFO1Data;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_D_OUT = VL_ULL(0);
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__rg_dmireset 
        = ((IData)(vlTOPp->mkTbSoc__DOT__trst__DOT__rst) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__rg_dmireset_1_whas) 
              & ((0U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)) 
                 & (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dtmcontrol_shiftreg 
                    >> 0x10U))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (((3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)) 
                  & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg) 
                    | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__capture_repsonse_from_dm)))) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_status 
                = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas)
                    ? 0U : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)
                             ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__spliced_bits___05Fh4970)
                             : 3U));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_status = 0U;
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_ENQ) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg = 1U;
        } else {
            if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_DEQ) {
                vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg = 0U;
            }
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg = 0U;
    }
}

VL_INLINE_OPT void VmkTbSoc::_sequent__TOP__11(VmkTbSoc__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VmkTbSoc::_sequent__TOP__11\n"); );
    VmkTbSoc* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmistat 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__spliced_bits___05Fh4970;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmistat = 0U;
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__rg_dmireset_1_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__rg_dmihardreset 
                = ((0U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)) 
                   & (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dtmcontrol_shiftreg 
                      >> 0x11U));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__rg_dmihardreset = 0U;
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)) 
              | (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (0x10U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dtmcontrol_shiftreg 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dtmcontrol_shiftreg_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dtmcontrol_shiftreg = 0x7061U;
    }
}

VL_INLINE_OPT void VmkTbSoc::_sequent__TOP__13(VmkTbSoc__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VmkTbSoc::_sequent__TOP__13\n"); );
    VmkTbSoc* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15 
            = (1U & VL_TESTPLUSARGS_I("fullverbose"));
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16 
            = (1U & VL_TESTPLUSARGS_I("mjtag"));
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17 
            = (1U & VL_TESTPLUSARGS_I("l0"));
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d22 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d24 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d26 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d28 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d30 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d32 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d34 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d36 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d38 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d46 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0xcU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d40 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (9U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d42 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0xaU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d44 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0xbU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d48 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0xdU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d50 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
           & (0xeU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d80 
        = (((((((((((((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
                          | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
                             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))) 
                         & (0U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                        & (1U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                       & (2U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                      & (3U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                     & (4U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                    & (5U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                   & (6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                  & (7U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                 & (8U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                & (9U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
               & (0xaU != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0xbU != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (0xcU != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
            & (0xdU != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
           & (0xeU != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate)));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh2853 
            = VL_TIME_Q();
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
                         | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh2853);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
                         | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))))) {
            VL_WRITEF("\tTAPSTATE: ");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d22)) {
            VL_WRITEF("TestLogicReset");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d24)) {
            VL_WRITEF("RunTestIdle");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d26)) {
            VL_WRITEF("SelectDRScan");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d28)) {
            VL_WRITEF("CaptureDR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d30)) {
            VL_WRITEF("ShiftDR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d32)) {
            VL_WRITEF("Exit1DR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d34)) {
            VL_WRITEF("PauseDR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d36)) {
            VL_WRITEF("Exit2DR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d38)) {
            VL_WRITEF("UpdateDR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d40)) {
            VL_WRITEF("SelectIRScan");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d42)) {
            VL_WRITEF("CaptureIR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d44)) {
            VL_WRITEF("ShiftIR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d46)) {
            VL_WRITEF("Exit1IR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d48)) {
            VL_WRITEF("PauseIR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d50)) {
            VL_WRITEF("Exit2IR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs_5_OR_TASK_testplusargs_6_AND_ETC___05F_d80)) {
            VL_WRITEF("UpdateIR");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
                         | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))))) {
            VL_WRITEF("\tINSTRUCTION: %x",5,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction_shiftreg);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d15) 
                         | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d16) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d17))))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d225 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d226 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d227 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d230 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d225) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d226) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d227))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh4632 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d230)))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh4632);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d230)))) {
            VL_WRITEF("\tDTM: Getting response: data %x op: %x",
                      32,(IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_D_OUT 
                                  >> 2U)),2,(3U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_D_OUT)));
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d230)))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d234 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d235 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d236 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d239 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d234) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d235) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d236))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5178 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d239)))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5178);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d239)))) {
            VL_WRITEF("\tDTM: New DMIACCESS value: %x",
                      34,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__x___05Fh4887);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM_i_notEmpty___05F86_AND_TASK_testp_ETC___05F_d239)))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d246 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d247 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d248 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_response_from_DM_i_notEmpty___05F86_43_AND_TAS_ETC___05F_d251 
        = ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d246) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d247) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d248))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
               & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
              & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
             & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__response_from_DM__DOT__empty_reg)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5372 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_response_from_DM_i_notEmpty___05F86_43_AND_TAS_ETC___05F_d251)))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5372);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_response_from_DM_i_notEmpty___05F86_43_AND_TAS_ETC___05F_d251)))) {
            VL_WRITEF("\tDTM: RESPONSE NOT AVAILABLE. DMIACCESS: %x",
                      40,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmiaccess_shiftreg);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_response_from_DM_i_notEmpty___05F86_43_AND_TAS_ETC___05F_d251)))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_re_ETC___05F_d198))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d255 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_re_ETC___05F_d198))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d256 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_re_ETC___05F_d198))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d257 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_i_notFull___05F90_AND_NOT_dmiaccess___05FETC___05F_d260 
        = ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg)) 
             & (0U != (3U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmiaccess_shiftreg)))) 
            & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__capture_repsonse_from_dm))) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d255) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d256) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d257))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_re_ETC___05F_d198))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5615 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_i_notFull___05F90_AND_NOT_dmiaccess___05FETC___05F_d260)))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5615);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_i_notFull___05F90_AND_NOT_dmiaccess___05FETC___05F_d260)))) {
            VL_WRITEF("\tDTM: Sending request to Debug: %x",
                      40,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmiaccess_shiftreg);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM_i_notFull___05F90_AND_NOT_dmiaccess___05FETC___05F_d260)))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_NO_ETC___05F_d267))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d269 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_NO_ETC___05F_d267))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d270 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_NO_ETC___05F_d267))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d271 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_request_to_DM_i_notFull___05F90_64_OR_dmiacces_ETC___05F_d274 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__request_to_DM__DOT__empty_reg) 
             | (0U == (3U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmiaccess_shiftreg)))) 
            | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__capture_repsonse_from_dm)) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d269) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d270) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d271))));
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
              & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__crossed_instruction_wget___05F51_EQ_0x11_85_AND_NO_ETC___05F_d267))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5695 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_request_to_DM_i_notFull___05F90_64_OR_dmiacces_ETC___05F_d274)))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh5695);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_request_to_DM_i_notFull___05F90_64_OR_dmiacces_ETC___05F_d274)))) {
            VL_WRITEF("\tDTM: REQUEST NOT SERVED capture: %b DMIACCESS: %x",
                      1,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__capture_repsonse_from_dm,
                      40,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__dmiaccess_shiftreg);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmihardreset_generated_whas)) 
                           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__tapstate))) 
                          & (0x11U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__instruction))) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__NOT_request_to_DM_i_notFull___05F90_64_OR_dmiacces_ETC___05F_d274)))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d139 
                = (1U & VL_TESTPLUSARGS_I("fullverbose"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d140 
                = (1U & VL_TESTPLUSARGS_I("mjtag"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d141 
                = (1U & VL_TESTPLUSARGS_I("l0"));
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh3488 
                = VL_TIME_Q();
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) 
                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d139) 
                            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d140) 
                               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d141)))))) {
            VL_WRITEF("[%10#] ",64,vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__v___05Fh3488);
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) 
                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d139) 
                            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d140) 
                               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d141)))))) {
            VL_WRITEF("\tDTM: Received DMIRESET");
            fflush(stdout);
        }
    }
    if (vlTOPp->mkTbSoc__DOT__trst__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__wr_dmireset_generated_whas) 
                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d139) 
                            | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d140) 
                               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__jtag_tap__DOT__TASK_testplusargs___05F_d141)))))) {
            VL_WRITEF("\n");
            fflush(stdout);
        }
    }
}

VL_INLINE_OPT void VmkTbSoc::_sequent__TOP__14(VmkTbSoc__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VmkTbSoc::_sequent__TOP__14\n"); );
    VmkTbSoc* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    // Begin mtask footprint all: 
    WData/*95:0*/ __Vtemp6502[3];
    WData/*127:0*/ __Vtemp6503[4];
    WData/*159:0*/ __Vtemp6504[5];
    WData/*191:0*/ __Vtemp6505[6];
    WData/*223:0*/ __Vtemp6506[7];
    WData/*255:0*/ __Vtemp6507[8];
    WData/*287:0*/ __Vtemp6508[9];
    WData/*319:0*/ __Vtemp6509[10];
    WData/*351:0*/ __Vtemp6510[11];
    WData/*383:0*/ __Vtemp6511[12];
    WData/*415:0*/ __Vtemp6512[13];
    WData/*447:0*/ __Vtemp6513[14];
    WData/*479:0*/ __Vtemp6514[15];
    WData/*511:0*/ __Vtemp6515[16];
    WData/*511:0*/ __Vtemp6566[16];
    WData/*511:0*/ __Vtemp6567[16];
    WData/*95:0*/ __Vtemp6591[3];
    WData/*95:0*/ __Vtemp6592[3];
    WData/*95:0*/ __Vtemp6600[3];
    WData/*159:0*/ __Vtemp6615[5];
    WData/*95:0*/ __Vtemp6619[3];
    WData/*95:0*/ __Vtemp6622[3];
    WData/*191:0*/ __Vtemp6634[6];
    // Body
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__ras_stack_array_reg_D_OUT_1 
        = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__ras_stack_array_reg__DOT__arr
        [(7U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__ras_stack_top_index) 
                - (IData)(1U)))];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[1U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[1U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[1U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[2U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[2U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[2U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[3U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[3U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[3U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[4U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[4U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[4U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[5U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[5U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[5U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[6U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[6U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[6U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[7U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[7U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[7U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[8U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[8U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[8U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[9U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[9U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[9U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xaU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xaU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xaU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xbU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xbU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xbU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xcU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xcU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xcU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xdU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xdU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xdU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xeU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xeU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xeU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xfU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xfU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xfU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d479 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_3
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_2)
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_1
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_0));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_enables_0_20_fb_enables_1_14_fb_ena_ETC___05F_d476 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_3)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_2))
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_1)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_0)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[1U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[1U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[1U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[1U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[1U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[2U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[2U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[2U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[2U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[2U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[3U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[3U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[3U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[3U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[3U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[4U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[4U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[4U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[4U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[4U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[5U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[5U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[5U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[5U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[5U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[6U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[6U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[6U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[6U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[6U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[7U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[7U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[7U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[7U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[7U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[8U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[8U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[8U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[8U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[8U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[9U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[9U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[9U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[9U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[9U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xaU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xaU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xaU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xaU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xaU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xbU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xbU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xbU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xbU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xbU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xcU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xcU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xcU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xcU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xcU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xdU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xdU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xdU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xdU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xdU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xeU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xeU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xeU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xeU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xeU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh311709[0xfU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xfU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xfU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xfU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xfU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d2242 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_7
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_6)
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_5
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_4))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_3
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_2)
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_1
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_0)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_enables_0_read___05F526_fb_enables_1_re_ETC___05F_d2240 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_7)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_6))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_5)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_4)))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_3)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_2))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_1)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_0))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_find_center_of_bit_cell 
        = ((1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_parity_bit 
        = ((4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_stop_first_bit 
        = ((5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_stop_last_bit 
        = ((6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_buffer_shift 
        = ((3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_wait_bit_cell_time_for_sample 
        = (((2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
            & (0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvCellCount))) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_wait_for_start_bit 
        = ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_find_center_of_bit_cell 
        = ((1U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_parity_bit 
        = ((4U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_stop_first_bit 
        = ((5U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_stop_last_bit 
        = ((6U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_buffer_shift 
        = ((3U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_wait_bit_cell_time_for_sample 
        = (((2U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
            & (0xfU == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvCellCount))) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_wait_for_start_bit 
        = ((0U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__target___05F___05F2___05Fh424103 
        = ((0U == vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT___theResult___05F___05F_6___05Fh40168)
            ? (((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[2U])) 
                << 0x3eU) | (((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[1U])) 
                              << 0x1eU) | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[0U])) 
                                           >> 2U)))
            : ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__v_reg_btb_tag_0_83_BITS_62_TO_1_84_EQ_mav_pred_ETC___05F_d7054) 
                      | (~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[0U])))
                ? ((3U == (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__v_reg_btb_tag_0_83_BITS_62_TO_1_84_EQ_mav_pred_ETC___05F_d6453) 
                            << 1U) | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__v_reg_btb_tag_0_83_BITS_62_TO_1_84_EQ_mav_pred_ETC___05F_d6548)))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__ras_stack_array_reg_D_OUT_1
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu__DOT__hit_entry_target___05Fh42210)
                : (((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[2U])) 
                    << 0x3eU) | (((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[1U])) 
                                  << 0x1eU) | ((QData)((IData)(
                                                               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__bpu_mav_prediction_response_r[0U])) 
                                               >> 2U)))));
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache_EN_core_req_put) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_latest_index 
                = (0x3fU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__ff_to_cache_rv_port1___05Fread[1U] 
                             << 0x16U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__ff_to_cache_rv_port1___05Fread[0U] 
                                          >> 0xaU)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_latest_index = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache_EN_core_req_put) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fence_stall 
                = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache_EN_core_req_put) 
                   & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__ff_to_cache_rv_port1___05Fread[0U] 
                      >> 1U));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fence_stall = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_respond_to_core) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_request_to_memory))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_miss_ongoing 
                = (1U & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_respond_to_core)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_miss_ongoing = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_request_to_memory) 
                 & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate))) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable)) 
               & (0x80000000U <= (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_from_tlb_rv_port1___05Fread 
                                          >> 7U)))) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                 & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_fb_enables_2_write_1___05FSEL_2));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2 = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_request_to_memory) 
                 & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate))) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable)) 
               & (0x80000000U <= (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_from_tlb_rv_port1___05Fread 
                                          >> 7U)))) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                 & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_fb_enables_1_write_1___05FSEL_2));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1 = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_request_to_memory) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate))) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable)) 
               & (0x80000000U <= (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_from_tlb_rv_port1___05Fread 
                                          >> 7U)))) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_fb_enables_0_write_1___05FSEL_2));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0 = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_replaylatest_EN) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_replaylatest 
                = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                     & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_NOT_fb_err_0_75_112_NOT_fb_err_1_74_11_ETC___05F_d1117)) 
                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0_9_AND_fb_valid_1_0_AND_fb_valid_2_1_ETC___05F_d25)) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1093));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_replaylatest = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_request_to_memory) 
                 & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate))) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable)) 
               & (0x80000000U <= (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_from_tlb_rv_port1___05Fread 
                                          >> 7U)))) 
              | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                 & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)))) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_fb_enables_3_write_1___05FSEL_2));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3 = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_EN_core_req_put) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_latest_index 
                = (0x3fU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[3U] 
                             << 0xdU) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[2U] 
                                         >> 0x13U)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_latest_index = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_rg_miss_ongoing_write_1___05FSEL_1) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_miss_ongoing 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_rg_miss_ongoing_write_1___05FSEL_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_miss_ongoing = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget)) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_EN_core_req_put))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fence_stall 
                = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_rg_fence_stall_write_1___05FSEL_1)) 
                         & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[2U] 
                            >> 0xcU)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fence_stall = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
             & (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_rg_valid_0_79_rg_valid_1_80_rg_valid_2_ETC___05F_d2694)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_readdone)) 
                | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_NOT_fb_err_0_read___05F638_698_NOT_fb_err___05FETC___05F_d2707))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo3)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo3))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_6_write_1___05FSEL_2) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_6_write_1___05FSEL_1)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo5)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo5))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_5_write_1___05FSEL_2) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_5_write_1___05FSEL_1)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo7)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo7))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_4_write_1___05FSEL_2) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_4_write_1___05FSEL_1)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo9)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo9))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_enables_3_write_1___05FSEL_1) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_valid_3_write_1___05FSEL_3)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo11)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo11))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_enables_2_write_1___05FSEL_1) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_valid_2_write_1___05FSEL_3)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo13)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo13))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_enables_1_write_1___05FSEL_1) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_valid_1_write_1___05FSEL_3)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo15)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo15))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_enables_0_write_1___05FSEL_1) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_valid_0_write_1___05FSEL_3)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_allocate_storebuffer) 
              & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail))) 
             | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_initiate_store) 
                & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_0_1 
                = (1U & (~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_initiate_store) 
                            & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead)))));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_0_1 = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_allocate_storebuffer) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail)) 
             | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_initiate_store) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_1_1 
                = (1U & (~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_initiate_store) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead))));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_1_1 = 0U;
    }
    if (vlTOPp->RST_N) {
        if (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
               & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fenceinit))) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty)) 
             & (0U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh277884)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select = 1U;
    }
    if (vlTOPp->RST_N) {
        if ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
              & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fenceinit))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select 
                = (0x3fU & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh28131));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_replaylatest_EN) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_replaylatest 
                = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___write_RL_release_from_FB_EN_rg_replaylatest_wget));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_replaylatest = 0U;
    }
    if (vlTOPp->RST_N) {
        if ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo1)) 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget))) 
              | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                   & (7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                  & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                   << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                >> 9U))))) 
                 & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))) 
             | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                  & (7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7 
                = ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__WILL_FIRE_RL_release_from_FB) 
                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___dfoo1))) 
                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_7_write_1___05FSEL_2) 
                      | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_addr_7_write_1___05FSEL_1)));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7 = 0U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202 
        = (0xffffU & ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_enables_0_20_fb_enables_1_14_fb_ena_ETC___05F_d476))
                       ? (((IData)(1U) << (0xfU & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d479 
                                                   >> 2U))) 
                          | ((IData)(1U) << (0xfU & 
                                             ((IData)(1U) 
                                              + (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d479 
                                                 >> 2U)))))
                       : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbfillenable)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237 
        = (0xffU & ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_enables_0_read___05F526_fb_enables_1_re_ETC___05F_d2240))
                     ? ((IData)(1U) << (7U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d2242 
                                              >> 3U)))
                     : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbfillenable)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvCellCount_D_IN 
        = (((((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_find_center_of_bit_cell) 
                  & (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvCellCount))) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_stop_last_bit)) 
                | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_stop_first_bit)) 
               | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_parity_bit)) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_buffer_shift)) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_wait_bit_cell_time_for_sample)) 
            | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_wait_for_start_bit))
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvCellCount))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_pwRecvResetBitCount_whas 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_receive_wait_for_start_bit) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvData));
    vlTOPp->mkTbSoc__DOT__uart_uart_rRecvCellCount_D_IN 
        = (((((((((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_find_center_of_bit_cell) 
                  & (4U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvCellCount))) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_stop_last_bit)) 
                | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_stop_first_bit)) 
               | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_parity_bit)) 
              | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_buffer_shift)) 
             | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_wait_bit_cell_time_for_sample)) 
            | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_wait_for_start_bit))
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvCellCount))));
    vlTOPp->mkTbSoc__DOT__uart_uart_pwRecvResetBitCount_whas 
        = ((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_receive_wait_for_start_bit) 
           & (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvData));
    if (vlTOPp->RST_N) {
        if (((((((((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_shift_next_bit) 
                   | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_1_bit_cell_time)) 
                  | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_parity_bit)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_start_bit)) 
                | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit2)) 
               | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit1_5)) 
              | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit)) 
             | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_for_start_command))) {
            vlTOPp->mkTbSoc__DOT__uart_uart_rXmitDataOut 
                = (((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_shift_next_bit) 
                    | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_1_bit_cell_time))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_vrXmitBuffer_0)
                    : ((~ ((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_parity_bit) 
                           | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_start_bit))) 
                       & ((((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit2) 
                            | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit1_5)) 
                           | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit)) 
                          | (IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_for_start_command))));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__uart_uart_rXmitDataOut = 1U;
    }
    if (vlTOPp->RST_N) {
        if (((((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_shift_next_bit) 
                   | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_1_bit_cell_time)) 
                  | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_parity_bit)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_start_bit)) 
                | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit2)) 
               | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit1_5)) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit)) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_for_start_command))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitDataOut 
                = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_shift_next_bit) 
                    | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_1_bit_cell_time))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_vrXmitBuffer_0)
                    : ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_parity_bit) 
                           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_start_bit))) 
                       & ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit2) 
                            | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit1_5)) 
                           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit)) 
                          | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_for_start_command))));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitDataOut = 1U;
    }
    if (vlTOPp->RST_N) {
        if (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_connect_debug_response_to_syncfifo) 
             & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sEnqToggle) 
                == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sDeqToggle)))) {
            vlTOPp->__Vdly__mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sEnqToggle 
                = (1U & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sEnqToggle)));
            vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__syncFIFO1Data 
                = (VL_ULL(0x3ffffffff) & vlTOPp->mkTbSoc__DOT__soc__DOT__debug_module__DOT__dmi_response);
        }
    } else {
        vlTOPp->__Vdly__mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sEnqToggle = 0U;
        vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__syncFIFO1Data = VL_ULL(0);
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_fb_enables_0_write_1___05FVAL_1 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_enables_0_20_fb_enables_1_14_fb_ena_ETC___05F_d476) 
           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0U] 
        = VL_NEGATE_I((IData)((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[1U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 1U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[2U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 2U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[3U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 3U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[4U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 4U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[5U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 5U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[6U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 6U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[7U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 7U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[8U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 8U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[9U] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 9U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xaU] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 0xaU))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xbU] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 0xbU))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xcU] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 0xcU))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xdU] 
        = VL_NEGATE_I((IData)((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                     >> 0xdU))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xeU] 
        = (IData)((((QData)((IData)(VL_NEGATE_I((IData)(
                                                        (1U 
                                                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 0xfU)))))) 
                    << 0x20U) | (QData)((IData)(VL_NEGATE_I((IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 0xeU))))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xfU] 
        = (IData)(((((QData)((IData)(VL_NEGATE_I((IData)(
                                                         (1U 
                                                          & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                             >> 0xfU)))))) 
                     << 0x20U) | (QData)((IData)(VL_NEGATE_I((IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                         >> 0xeU))))))) 
                   >> 0x20U));
    __Vtemp6502[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 0xdU)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 0xdU)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xdU)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xdU)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xdU)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 0xdU)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xdU)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xdU)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 0xdU)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 0xdU)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 0xdU)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 0xdU)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 0xdU)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 0xdU)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 0xdU)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 0xdU)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 0xdU)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 0xdU)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xdU))))))))))))))))))))))))))))))))));
    __Vtemp6502[1U] = (IData)((((QData)((IData)(((0x80000000U 
                                                  & ((~ 
                                                      ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                       >> 0xfU)) 
                                                     << 0x1fU)) 
                                                 | ((0x40000000U 
                                                     & ((~ 
                                                         ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                          >> 0xfU)) 
                                                        << 0x1eU)) 
                                                    | ((0x20000000U 
                                                        & ((~ 
                                                            ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                             >> 0xfU)) 
                                                           << 0x1dU)) 
                                                       | ((0x10000000U 
                                                           & ((~ 
                                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                >> 0xfU)) 
                                                              << 0x1cU)) 
                                                          | ((0x8000000U 
                                                              & ((~ 
                                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                   >> 0xfU)) 
                                                                 << 0x1bU)) 
                                                             | ((0x4000000U 
                                                                 & ((~ 
                                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                      >> 0xfU)) 
                                                                    << 0x1aU)) 
                                                                | ((0x2000000U 
                                                                    & ((~ 
                                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                         >> 0xfU)) 
                                                                       << 0x19U)) 
                                                                   | ((0x1000000U 
                                                                       & ((~ 
                                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                            >> 0xfU)) 
                                                                          << 0x18U)) 
                                                                      | ((0x800000U 
                                                                          & ((~ 
                                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                               >> 0xfU)) 
                                                                             << 0x17U)) 
                                                                         | ((0x400000U 
                                                                             & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x16U)) 
                                                                            | ((0x200000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x15U)) 
                                                                               | ((0x100000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)))))))))))))))))))))))))))))))))))) 
                                << 0x20U) | (QData)((IData)(
                                                            ((0x80000000U 
                                                              & ((~ 
                                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                   >> 0xeU)) 
                                                                 << 0x1fU)) 
                                                             | ((0x40000000U 
                                                                 & ((~ 
                                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                      >> 0xeU)) 
                                                                    << 0x1eU)) 
                                                                | ((0x20000000U 
                                                                    & ((~ 
                                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                         >> 0xeU)) 
                                                                       << 0x1dU)) 
                                                                   | ((0x10000000U 
                                                                       & ((~ 
                                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                            >> 0xeU)) 
                                                                          << 0x1cU)) 
                                                                      | ((0x8000000U 
                                                                          & ((~ 
                                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                               >> 0xeU)) 
                                                                             << 0x1bU)) 
                                                                         | ((0x4000000U 
                                                                             & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x1aU)) 
                                                                            | ((0x2000000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x19U)) 
                                                                               | ((0x1000000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU))))))))))))))))))))))))))))))))))))));
    __Vtemp6502[2U] = (IData)(((((QData)((IData)(((0x80000000U 
                                                   & ((~ 
                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                        >> 0xfU)) 
                                                      << 0x1fU)) 
                                                  | ((0x40000000U 
                                                      & ((~ 
                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                           >> 0xfU)) 
                                                         << 0x1eU)) 
                                                     | ((0x20000000U 
                                                         & ((~ 
                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                              >> 0xfU)) 
                                                            << 0x1dU)) 
                                                        | ((0x10000000U 
                                                            & ((~ 
                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                 >> 0xfU)) 
                                                               << 0x1cU)) 
                                                           | ((0x8000000U 
                                                               & ((~ 
                                                                   ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                    >> 0xfU)) 
                                                                  << 0x1bU)) 
                                                              | ((0x4000000U 
                                                                  & ((~ 
                                                                      ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                       >> 0xfU)) 
                                                                     << 0x1aU)) 
                                                                 | ((0x2000000U 
                                                                     & ((~ 
                                                                         ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                          >> 0xfU)) 
                                                                        << 0x19U)) 
                                                                    | ((0x1000000U 
                                                                        & ((~ 
                                                                            ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                             >> 0xfU)) 
                                                                           << 0x18U)) 
                                                                       | ((0x800000U 
                                                                           & ((~ 
                                                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                              << 0x17U)) 
                                                                          | ((0x400000U 
                                                                              & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x16U)) 
                                                                             | ((0x200000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xfU)))))))))))))))))))))))))))))))))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             ((0x80000000U 
                                                               & ((~ 
                                                                   ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                    >> 0xeU)) 
                                                                  << 0x1fU)) 
                                                              | ((0x40000000U 
                                                                  & ((~ 
                                                                      ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                       >> 0xeU)) 
                                                                     << 0x1eU)) 
                                                                 | ((0x20000000U 
                                                                     & ((~ 
                                                                         ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                          >> 0xeU)) 
                                                                        << 0x1dU)) 
                                                                    | ((0x10000000U 
                                                                        & ((~ 
                                                                            ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                             >> 0xeU)) 
                                                                           << 0x1cU)) 
                                                                       | ((0x8000000U 
                                                                           & ((~ 
                                                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                              << 0x1bU)) 
                                                                          | ((0x4000000U 
                                                                              & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x1aU)) 
                                                                             | ((0x2000000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xeU))))))))))))))))))))))))))))))))))))) 
                               >> 0x20U));
    __Vtemp6503[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 0xcU)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 0xcU)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xcU)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xcU)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xcU)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 0xcU)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xcU)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xcU)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 0xcU)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 0xcU)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 0xcU)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 0xcU)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 0xcU)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 0xcU)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 0xcU)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 0xcU)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 0xcU)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 0xcU)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xcU))))))))))))))))))))))))))))))))));
    __Vtemp6504[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 0xbU)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 0xbU)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xbU)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xbU)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xbU)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 0xbU)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xbU)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xbU)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 0xbU)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 0xbU)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 0xbU)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 0xbU)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 0xbU)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 0xbU)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 0xbU)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 0xbU)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 0xbU)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 0xbU)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xbU))))))))))))))))))))))))))))))))));
    __Vtemp6505[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 0xaU)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 0xaU)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xaU)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xaU)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xaU)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 0xaU)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 0xaU)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 0xaU)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 0xaU)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 0xaU)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 0xaU)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 0xaU)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 0xaU)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 0xaU)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 0xaU)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 0xaU)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 0xaU)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 0xaU)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 0xaU))))))))))))))))))))))))))))))))));
    __Vtemp6506[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 9U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 9U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 9U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 9U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 9U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 9U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 9U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 9U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 9U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 9U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 9U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 9U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 9U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 9U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 9U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 9U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 9U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 9U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 9U))))))))))))))))))))))))))))))))));
    __Vtemp6507[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 8U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 8U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 8U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 8U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 8U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 8U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 8U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 8U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 8U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 8U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 8U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 8U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 8U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 8U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 8U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 8U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 8U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 8U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 8U))))))))))))))))))))))))))))))))));
    __Vtemp6508[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 7U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 7U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 7U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 7U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 7U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 7U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 7U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 7U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 7U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 7U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 7U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 7U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 7U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 7U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 7U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 7U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 7U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 7U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 7U))))))))))))))))))))))))))))))))));
    __Vtemp6509[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 6U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 6U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 6U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 6U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 6U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 6U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 6U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 6U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 6U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 6U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 6U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 6U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 6U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 6U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 6U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 6U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 6U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 6U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 6U))))))))))))))))))))))))))))))))));
    __Vtemp6510[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 5U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 5U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 5U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 5U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 5U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 5U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 5U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 5U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 5U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 5U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 5U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 5U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 5U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 5U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 5U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 5U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 5U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 5U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 5U))))))))))))))))))))))))))))))))));
    __Vtemp6511[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 4U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 4U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 4U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 4U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 4U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 4U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 4U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 4U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 4U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 4U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 4U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 4U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 4U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 4U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 4U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 4U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 4U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 4U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 4U))))))))))))))))))))))))))))))))));
    __Vtemp6512[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 3U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 3U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 3U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 3U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 3U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 3U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 3U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 3U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 3U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 3U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 3U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 3U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 3U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 3U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 3U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 3U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 3U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 3U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 3U))))))))))))))))))))))))))))))))));
    __Vtemp6513[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 2U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 2U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 2U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 2U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 2U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 2U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 2U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 2U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 2U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 2U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 2U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 2U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 2U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 2U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 2U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 2U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 2U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 2U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 2U))))))))))))))))))))))))))))))))));
    __Vtemp6514[0U] = ((0x80000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                           >> 1U)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                            >> 1U)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 1U)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 1U)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 1U)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ 
                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                     >> 1U)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                               >> 1U)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                  >> 1U)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                   >> 1U)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ 
                                                     ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                      >> 1U)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ 
                                                        ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                         >> 1U)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                            >> 1U)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ 
                                                              ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                               >> 1U)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ 
                                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                  >> 1U)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ 
                                                                    ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                     >> 1U)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ 
                                                                       ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                        >> 1U)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ 
                                                                          ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                           >> 1U)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ 
                                                                             ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                              >> 1U)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ 
                                                                                ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202) 
                                                                                >> 1U))))))))))))))))))))))))))))))))));
    __Vtemp6515[0U] = ((0x80000000U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                       << 0x1fU)) | 
                       ((0x40000000U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                        << 0x1eU)) 
                        | ((0x20000000U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                           << 0x1dU)) 
                           | ((0x10000000U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                              << 0x1cU)) 
                              | ((0x8000000U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                << 0x1bU)) 
                                 | ((0x4000000U & (
                                                   (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                   << 0x1aU)) 
                                    | ((0x2000000U 
                                        & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                           << 0x19U)) 
                                       | ((0x1000000U 
                                           & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                              << 0x18U)) 
                                          | ((0x800000U 
                                              & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                 << 0x17U)) 
                                             | ((0x400000U 
                                                 & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                    << 0x16U)) 
                                                | ((0x200000U 
                                                    & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                       << 0x15U)) 
                                                   | ((0x100000U 
                                                       & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                          << 0x14U)) 
                                                      | ((0x80000U 
                                                          & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                             << 0x13U)) 
                                                         | ((0x40000U 
                                                             & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                << 0x12U)) 
                                                            | ((0x20000U 
                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                   << 0x11U)) 
                                                               | ((0x10000U 
                                                                   & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                      << 0x10U)) 
                                                                  | ((0x8000U 
                                                                      & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                         << 0xfU)) 
                                                                     | ((0x4000U 
                                                                         & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                            << 0xeU)) 
                                                                        | ((0x2000U 
                                                                            & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                               << 0xdU)) 
                                                                           | ((0x1000U 
                                                                               & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 0xcU)) 
                                                                              | ((0x800U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_2___05Fh30202))))))))))))))))))))))))))))))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0U] 
        = __Vtemp6515[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[1U] 
        = __Vtemp6514[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[2U] 
        = __Vtemp6513[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[3U] 
        = __Vtemp6512[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[4U] 
        = __Vtemp6511[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[5U] 
        = __Vtemp6510[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[6U] 
        = __Vtemp6509[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[7U] 
        = __Vtemp6508[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[8U] 
        = __Vtemp6507[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[9U] 
        = __Vtemp6506[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xaU] 
        = __Vtemp6505[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xbU] 
        = __Vtemp6504[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xcU] 
        = __Vtemp6503[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xdU] 
        = __Vtemp6502[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xeU] 
        = __Vtemp6502[1U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xfU] 
        = __Vtemp6502[2U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_enables_0_write_1___05FVAL_4 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_enables_0_read___05F526_fb_enables_1_re_ETC___05F_d2240) 
           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0U] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[1U] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[2U] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 1U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[3U] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 1U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[4U] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[5U] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 2U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[6U] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 3U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[7U] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 3U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[8U] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 4U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[9U] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 4U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xaU] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 5U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xbU] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 5U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xcU] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 6U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xdU] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 6U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xeU] 
        = (IData)(VL_NEGATE_Q((QData)((IData)((1U & 
                                               ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                >> 7U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_1___05Fh311600[0xfU] 
        = (IData)((VL_NEGATE_Q((QData)((IData)((1U 
                                                & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___theResult___05F___05F_6___05Fh311237) 
                                                   >> 7U))))) 
                   >> 0x20U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvBitCount_D_IN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_pwRecvResetBitCount_whas)
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rRecvBitCount))));
    vlTOPp->mkTbSoc__DOT__uart_uart_rRecvBitCount_D_IN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__uart_uart_pwRecvResetBitCount_whas)
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rRecvBitCount))));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_shift_next_bit 
        = ((3U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_parity_bit 
        = ((7U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_start_bit 
        = ((1U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit2 
        = ((6U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit1_5 
        = ((5U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_send_stop_bit 
        = ((4U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_1_bit_cell_time 
        = ((2U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_for_start_command 
        = ((0U == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_baudGen_rBaudCounter_value_PLUS_1_8___05FETC___05F_d30)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_shift_next_bit 
        = ((3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_parity_bit 
        = ((7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_start_bit 
        = ((1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit2 
        = ((6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit1_5 
        = ((5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_send_stop_bit 
        = ((4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_1_bit_cell_time 
        = ((2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_for_start_command 
        = ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitState)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_baudGen_rBaudCounter_value___05FETC___05F_d11432)));
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__wr_total_cache_misses_whas) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__WILL_FIRE_RL_release_from_FB) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback = 0U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__NOT_fb_valid_0_9_6_AND_NOT_fb_valid_1_0_7_AND___05FETC___05F_d32 
        = (1U & ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0)) 
                   & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1))) 
                  & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2))) 
                 & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0_9_OR_fb_valid_1_0_OR_fb_valid_2_1_O_ETC___05F_d1103 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1)) 
            | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2)) 
           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0_9_AND_fb_valid_1_0_AND_fb_valid_2_1_ETC___05F_d25 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__NOT_fb_valid_0_9_6_OR_NOT_fb_valid_1_0_7_OR_NO_ETC___05F_d422 
        = (1U & ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0)) 
                   | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1))) 
                  | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2))) 
                 | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback_D_IN 
        = (7U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[1U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[1U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[1U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[1U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[1U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[1U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[2U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[2U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[2U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[2U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[2U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[2U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[3U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[3U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[3U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[3U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[3U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[3U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[4U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[4U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[4U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[4U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[4U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[4U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[5U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[5U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[5U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[5U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[5U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[5U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[6U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[6U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[6U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[6U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[6U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[6U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[7U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[7U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[7U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[7U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[7U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[7U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[8U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[8U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[8U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[8U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[8U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[8U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[9U] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[9U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[9U]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[9U])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[9U]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[9U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xaU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xaU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xaU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xaU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xaU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xaU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xbU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xbU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xbU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xbU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xbU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xbU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xcU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xcU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xcU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xcU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xcU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xcU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xdU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xdU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xdU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xdU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xdU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xdU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xeU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xeU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xeU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xeU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xeU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xeU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_2[0xfU] 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xfU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xfU]))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xfU])
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xfU]
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xfU])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_dirty_0_read___05F875_fb_dirty_1_read___05F_ETC___05F_d2884 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_7)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_6))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_5)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_4)))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_3)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_2))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_1)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dirty_0))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh375884 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_7)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_6))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_5)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_4)))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_3)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_2))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_1)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_enables_0))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_NOT_fb_err_0_read___05F638_698_NOT_fb_err___05FETC___05F_d2707 
        = (1U & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_7))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_6)))
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_5))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_4))))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_3))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_2)))
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_1))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_err_0))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_7
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_6)
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_5
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_4))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_3
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_2)
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_1
                    : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_addr_0)));
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_initiate_store) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead = 0U;
    }
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_allocate_storebuffer) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail = 0U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select_D_IN 
        = ((0xeU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                    << 1U)) | (1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                     >> 3U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162 
        = ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select))
            ? 0U : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select))
                     ? 1U : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select))
                              ? 2U : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select))
                                       ? 3U : 4U))));
    if (vlTOPp->RST_N) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fenceinit 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fenceinit = 1U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__bs___05Fh28594 
        = ((0x20U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
            ? ((0x10U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                ? ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_62))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_60)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_58))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_56))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_54))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_52)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_50))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_48)))))
                : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_46))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_44)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_42))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_40))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_38))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_36)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_34))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_32))))))
            : ((0x10U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                ? ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_30))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_28)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_26))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_24))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_22))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_20)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_18))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_16)))))
                : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_14))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_12)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_10))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_8))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_6))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_4)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_2))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh277884 
        = ((0x20U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
            ? ((0x10U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                ? ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_62))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_60)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_58))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_56))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_54))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_52)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_50))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_48)))))
                : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_46))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_44)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_42))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_40))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_38))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_36)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_34))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_32))))))
            : ((0x10U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                ? ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_30))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_28)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_26))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_24))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_22))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_20)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_18))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_16)))))
                : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_14))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_12)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_10))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_8))))
                    : ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_6))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_4)))
                        : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_2))
                            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_0)))))));
    if (vlTOPp->RST_N) {
        if ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_fence_operation) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget)) 
             | (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                 & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                  << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                               >> 9U))))) 
                & ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_fb_response_whas___05F732_THEN_wr_fb_respons_ETC___05F_d1734)) 
                   | (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty 
                = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
                    & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                     << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                                  >> 9U))))) 
                   & ((0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_fb_response_whas___05F732_THEN_wr_fb_respons_ETC___05F_d1734)) 
                      | (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730))));
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty = 0U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_valid_0_9_fb_valid_1_0_fb_valid_2_1_ETC___05F_d2600 
        = ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
            ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4)))
            : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2))
                : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbwriteback))
                    ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1)
                    : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1_0_AND_fb_valid_2_1_AND_fb_valid_3_2_ETC___05F_d32 
        = (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2)) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3)) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4)) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1_0_OR_fb_valid_2_1_OR_fb_valid_3_2_O_ETC___05F_d2225 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1) 
             | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2)) 
            | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3)) 
           | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4) 
                | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5)) 
               | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6)) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_1_0_5_AND_NOT_fb_valid_2_1_6_AND___05FETC___05F_d47 
        = (1U & (((((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1)) 
                      & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2))) 
                     & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3))) 
                    & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4))) 
                   & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5))) 
                  & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6))) 
                 & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_4_3_8_OR_NOT_fb_valid_5_4_9_OR_NO_ETC___05F_d1374 
        = (1U & ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4)) 
                   | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5))) 
                  | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6))) 
                 | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7))));
    if (vlTOPp->RST_N) {
        if (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_respond_to_core) 
               & (0U != (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[3U] 
                                << 0x17U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__data0_reg[2U] 
                                             >> 9U))))) 
              & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__IF_wr_cache_response_whas___05F728_THEN_wr_cache_r_ETC___05F_d1730))) 
             | (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_request_to_memory) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp2_mv_cacheenable) 
                    >> 1U)) & (0x80000000U <= (IData)(
                                                      (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_from_tlb_rv_port1___05Fread 
                                                       >> 8U)))))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate_D_IN;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate = 0U;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0U] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[1U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[1U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[1U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[1U] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[2U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[2U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[2U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[2U] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[3U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[3U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[3U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[3U] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[4U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[4U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[4U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[4U] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[5U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[5U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[5U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[5U] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[6U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[6U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[6U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[6U] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[7U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[7U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[7U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[7U] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[8U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[8U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[8U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[8U] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[9U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[9U] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[9U]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[9U] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xaU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xaU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xaU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xaU] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xbU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xbU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xbU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xbU] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xcU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xcU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xcU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xcU] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xdU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xdU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xdU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xdU] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xeU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xeU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xeU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xeU] 
              & (IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                        >> 2U))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0_D_IN[0xfU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh33632[0xfU] 
            & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__y___05Fh33633[0xfU]) 
           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT___theResult___05F___05F_1___05Fh33563[0xfU] 
              & (IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[2U])) 
                           << 0x3eU) | (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[1U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_read_mem_response_rv_port1___05Fread[0U])) 
                                           >> 2U))) 
                         >> 0x20U))));
    vlTOPp->mkTbSoc__DOT__uart_uart_rXmitBitCount_D_IN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_for_start_command)
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitBitCount))));
    vlTOPp->mkTbSoc__DOT__uart_uart_rXmitBitCount_EN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_for_start_command) 
           | (((IData)(vlTOPp->mkTbSoc__DOT__CAN_FIRE_RL_uart_uart_transmit_wait_1_bit_cell_time) 
               & (0xfU == (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitCellCount))) 
              & (7U != (IData)(vlTOPp->mkTbSoc__DOT__uart_uart_rXmitBitCount))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitBitCount_D_IN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_for_start_command)
            ? 0U : (0xfU & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitBitCount))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitBitCount_EN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_for_start_command) 
           | (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__CAN_FIRE_RL_uart_user_ifc_uart_transmit_wait_1_bit_cell_time) 
               & (0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitCellCount))) 
              & (7U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__uart_user_ifc_uart_rXmitBitCount))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sDeqToggle 
        = (1U & ((~ (IData)(vlTOPp->RST_N)) | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sSyncReg1)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__CAN_FIRE_RL_fence_operation 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_core_request__DOT__empty_reg) 
             & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_core_request__DOT__data0_reg[0U] 
                >> 1U)) & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fence_stall)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__NOT_fb_valid_0_9_6_AND_NOT_fb_valid_1_0_7_AND___05FETC___05F_d32));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache_RDY_core_req_put 
        = (((((~ (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_core_response_rv 
                          >> 0x29U))) & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_replaylatest))) 
             & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fence_stall))) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__NOT_fb_valid_0_9_6_OR_NOT_fb_valid_1_0_7_OR_NO_ETC___05F_d422)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__ff_core_request__DOT__full_reg));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d2586 
        = ((0x3fU & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324 
                     >> 6U)) == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_latest_index));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_repl_v_count_0_612_repl_v_count_1_613___05FETC___05F_d2677 
        = ((0x800U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
            ? ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_62))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_60)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_58))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_56))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_54))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_52)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_50))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_48)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_46))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_44)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_42))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_40))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_38))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_36)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_34))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_32))))))
            : ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_30))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_28)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_26))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_24))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_22))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_20)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_18))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_16)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_14))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_12)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_10))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_8))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_6))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_4)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_2))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__repl_v_count_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917 
        = ((0x800U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
            ? ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_62))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_60)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_58))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_56))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_54))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_52)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_50))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_48)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_46))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_44)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_42))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_40))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_38))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_36)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_34))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_32))))))
            : ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_30))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_28)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_26))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_24))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_22))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_20)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_18))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_16)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_14))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_12)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_10))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_8))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_6))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_4)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_2))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_valid_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918 
        = ((0x800U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
            ? ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_62))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_60)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_58))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_56))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_54))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_52)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_50))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_48)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_46))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_44)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_42))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_40))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_38))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_36)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_34))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_32))))))
            : ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_30))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_28)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_26))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_24))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_22))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_20)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_18))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_16)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_14))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_12)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_10))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_8))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_6))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_4)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_2))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_dirty_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_address___05Fh28113 
        = ((((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162))
              ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162))
                  ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_3_ram_single_0__DOT__out_reg
                  : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_2_ram_single_0__DOT__out_reg)
              : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162))
                  ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_1_ram_single_0__DOT__out_reg
                  : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_0_ram_single_0__DOT__out_reg)) 
            << 0xcU) | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select) 
                        << 6U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063 
        = (1U & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh277884) 
                  >> (3U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162))) 
                 & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__bs___05Fh28594) 
                    >> (3U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh28162)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh28131 
        = (0x7fU & ((1U & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                            >> 3U) | (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh277884))))
                     ? ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select))
                     : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response 
        = (((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_read_mem_response_rv_port1___05Fread[2U] 
             >> 2U) & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__empty_reg)) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1_0_OR_fb_valid_2_1_OR_fb_valid_3_2_O_ETC___05F_d2225)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_1_0_5_OR_NOT_fb_valid_2_1_6_OR_NO_ETC___05F_d1377 
        = (1U & ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1)) 
                   | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2))) 
                  | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3))) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_4_3_8_OR_NOT_fb_valid_5_4_9_OR_NO_ETC___05F_d1374)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate_D_IN 
        = (3U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbmissallocate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback_D_IN 
        = (3U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[1U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[1U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[1U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[2U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[2U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[2U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[3U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[3U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[3U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[4U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[4U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[4U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[5U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[5U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[5U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[6U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[6U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[6U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[7U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[7U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[7U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[8U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[8U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[8U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[9U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[9U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[9U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xaU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xaU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xaU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xbU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xbU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xbU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xcU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xcU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xcU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xdU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xdU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xdU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xeU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xeU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xeU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_data_arr_0_ram_single_0_request_3___05FVAL_1[0xfU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_3[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_2[0xfU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_1[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_dataline_0[0xfU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_NOT_fb_err_0_75_112_NOT_fb_err_1_74_11_ETC___05F_d1117 
        = (1U & ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                  ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                      ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_err_3))
                      : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_err_2)))
                  : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                      ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_err_1))
                      : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_err_0)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__x___05Fh101564 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_3)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_2))
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_1)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_enables_0)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_valid_0_9_fb_valid_1_0_fb_valid_2_1_ETC___05F_d1106 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_3)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_2))
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_1)
                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_valid_0)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_3
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_2)
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_fbwriteback))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_1
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__fb_addr_0));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911 
        = (((0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917)) 
            & (0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918)))
            ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_repl_v_count_0_612_repl_v_count_1_613___05FETC___05F_d2677)
            : ((0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917))
                ? ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918))
                    ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918))
                        ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918))
                            ? 0U : 1U) : 2U) : 3U) : 
               ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917))
                 ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917))
                     ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917))
                         ? 0U : 1U) : 2U) : 3U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead_D_IN 
        = (1U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead)));
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_rg_storehead_0_store_valid_0_1_1_store_va_ETC___05Fq4 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_1_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_rg_storehead_0_store_valid_0_1_1_store_va_ETC___05Fq4 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_0_1;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__addr___05Fh399391 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__addr___05Fh399391 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_fbindex_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_fbindex_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__epoch___05Fh399395 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_epoch_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__epoch___05Fh399395 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_epoch_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storehead) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_io_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_io_0;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail_D_IN 
        = (1U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail)));
    if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
               - (IData)(1U)))) {
        if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
                   - (IData)(1U)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_x95611_0_store_data_0_1_store_data_1_DONT_ETC___05Fq2 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_x95611_0_store_data_0_1_store_data_1_DONT_ETC___05Fq2 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_rg_storetail_0_store_data_0_1_store_data___05FETC___05Fq3 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CASE_rg_storetail_0_store_data_0_1_store_data___05FETC___05Fq3 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_data_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295787 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295787 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_0;
    }
    if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
        if (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295720 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295720 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_0;
    }
    if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
               - (IData)(1U)))) {
        if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
                   - (IData)(1U)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295609 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295609 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_size_0;
    }
    if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
               - (IData)(1U)))) {
        if ((1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_storetail) 
                   - (IData)(1U)))) {
            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295470 
                = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_1;
        }
    } else {
        vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295470 
            = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_addr_0;
    }
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[1U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[1U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[1U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[1U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[1U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[2U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[2U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[2U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[2U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[2U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[3U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[3U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[3U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[3U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[3U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[4U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[4U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[4U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[4U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[4U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[5U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[5U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[5U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[5U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[5U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[6U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[6U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[6U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[6U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[6U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[7U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[7U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[7U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[7U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[7U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[8U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[8U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[8U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[8U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[8U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[9U] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[9U]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[9U])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[9U])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[9U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xaU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xaU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xaU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xaU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xaU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xbU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xbU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xbU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xbU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xbU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xcU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xcU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xcU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xcU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xcU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xdU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xdU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xdU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xdU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xdU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xeU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xeU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xeU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xeU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xeU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_line___05F_1___05Fh28112[0xfU] 
        = ((((VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select)))) 
              & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xfU]) 
             | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                     & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                        >> 1U)))) & 
                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xfU])) 
            | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                    & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                       >> 2U)))) & 
               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xfU])) 
           | (VL_NEGATE_I((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty_and_valid___05Fh27063) 
                                   & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                                      >> 3U)))) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xfU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT___deq_RL_fence_operation_EN_ff_core_request_wget 
        = (1U & (((0x3fU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select)) 
                  & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_way_select) 
                      >> 3U) | (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh277884)))) 
                 | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh28117 
        = (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fenceinit)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_globaldirty))
            ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh28131)
            : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_set_select));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_1_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_2_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (2U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_3_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_4_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (4U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_5_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (5U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_6_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (6U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_7_write_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex_DEQ 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response) 
           & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_read_mem_response_rv_port1___05Fread[0U] 
              >> 1U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta__DOT__empty_reg) 
             & ((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst__DOT__empty_reg) 
                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3common__DOT__full_reg)) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3inst__DOT__full_reg)) 
                  & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__fpu__DOT__rg_multicycle_op)) 
                     & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__fpu__DOT__ff_input__DOT__empty_reg)))) 
                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type__DOT__full_reg)) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval__DOT__empty_reg))) 
            & (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__full_reg) 
                    & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_response_rv[2U] 
                          >> 8U))) & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_replaylatest))) 
                  & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fence_stall))) 
                 & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0)) 
                    | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_1_0_5_OR_NOT_fb_valid_2_1_6_OR_NO_ETC___05F_d1377))) 
                & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_0_1)) 
                   | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__store_valid_1_1)))) 
               & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__rg_tlb_miss)) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result__DOT__full_reg)))) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rg_stall)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_ff_core_response_rv_port0___05Fread___05F9_BIT_72___05FETC___05F_d3029 
        = (1U & ((((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_response_rv[2U] 
                       >> 8U)) & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_replaylatest))) 
                  & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fence_stall))) 
                 & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0)) 
                    | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_fb_valid_1_0_5_OR_NOT_fb_valid_2_1_6_OR_NO_ETC___05F_d1377))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate_D_IN 
        = (7U & ((IData)(1U) + (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_NOT_fb_valid_0_9_4_NOT_fb_valid_1_0_5___05FETC___05F_d2026 
        = (1U & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_7))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_6)))
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_5))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_4))))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_3))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_2)))
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__rg_fbmissallocate))
                          ? (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_1))
                          : (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_valid_0))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__sSyncReg1 
        = ((IData)(vlTOPp->RST_N) & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__sync_response_from_dm__DOT__dDeqToggle));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_replacement_v_count_0_122_replacement___05FETC___05F_d1187 
        = ((0x800U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
            ? ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_62))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_60)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_58))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_56))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_54))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_52)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_50))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_48)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_46))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_44)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_42))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_40))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_38))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_36)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_34))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_32))))))
            : ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_30))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_28)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_26))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_24))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_22))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_20)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_18))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_16)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_14))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_12)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_10))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_8))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_6))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_4)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_2))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__replacement_v_count_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640 
        = ((0x800U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
            ? ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_63)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_62))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_61)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_60)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_59)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_58))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_57)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_56))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_55)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_54))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_53)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_52)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_51)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_50))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_49)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_48)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_47)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_46))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_45)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_44)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_43)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_42))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_41)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_40))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_39)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_38))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_37)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_36)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_35)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_34))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_33)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_32))))))
            : ((0x400U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                ? ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_31)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_30))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_29)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_28)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_27)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_26))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_25)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_24))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_23)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_22))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_21)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_20)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_19)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_18))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_17)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_16)))))
                : ((0x200U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                    ? ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_15)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_14))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_13)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_12)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_11)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_10))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_9)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_8))))
                    : ((0x100U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                        ? ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_7)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_6))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_5)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_4)))
                        : ((0x80U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                            ? ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_3)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_2))
                            : ((0x40U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090)
                                ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_1)
                                : (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_valid_0)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1093 
        = ((0x3fU & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_fb_addr_0_16_fb_addr_1_10_fb_addr_2_04_ETC___05F_d1090 
                     >> 6U)) == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__rg_latest_index));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_rg_valid_0_write_1___05FVAL_1 
        = (0xfU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917) 
                   | ((IData)(1U) << (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_rg_dirty_0_write_1___05FVAL_1 
        = (0xfU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_dirty_0_read___05F875_fb_dirty_1_read___05F_ETC___05F_d2884)
                    ? ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918) 
                       | ((IData)(1U) << (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911)))
                    : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918) 
                       & (~ ((IData)(1U) << (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[1U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[1U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[1U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[1U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[2U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[2U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[2U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[2U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[3U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[3U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[3U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[3U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[4U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[4U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[4U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[4U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[5U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[5U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[5U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[5U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[6U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[6U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[6U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[6U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[7U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[7U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[7U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[7U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[8U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[8U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[8U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[8U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[9U] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[9U])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[9U]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[9U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xaU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xaU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xaU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xaU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xbU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xbU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xbU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xbU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xcU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xcU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xcU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xcU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xdU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xdU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xdU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xdU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xeU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xeU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xeU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xeU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh380270[0xfU] 
        = ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
            ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_3_ram_single_0__DOT__out_reg[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_2_ram_single_0__DOT__out_reg[0xfU])
            : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_1_ram_single_0__DOT__out_reg[0xfU]
                : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__data_arr_0_ram_single_0__DOT__out_reg[0xfU]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__final_address___05Fh380608 
        = ((((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
              ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                  ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_3_ram_single_0__DOT__out_reg
                  : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_2_ram_single_0__DOT__out_reg)
              : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911))
                  ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_1_ram_single_0__DOT__out_reg
                  : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__tag_arr_0_ram_single_0__DOT__out_reg)) 
            << 0xcU) | (0xfc0U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d1324));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh378534 
        = (1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__dirty___05Fh375918) 
                 >> (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_nc_write_request_D_IN[0U] 
        = ((0xfffff800U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098) 
                           << 0xbU)) | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_nc_write_request_D_IN[1U] 
        = ((0x7ffU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098) 
                      >> 0x15U)) | (0xfffff800U & ((IData)(
                                                           (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                                                            >> 0x20U)) 
                                                   << 0xbU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_nc_write_request_D_IN[2U] 
        = ((0x7ffU & ((IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                               >> 0x20U)) >> 0x15U)) 
           | (0xfffff800U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__addr___05Fh399391 
                             << 0xbU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_nc_write_request_D_IN[3U] 
        = (0x7ffU & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__addr___05Fh399391 
                     >> 0x15U));
    VL_EXTEND_WQ(512,64, __Vtemp6566, ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003))
                                        ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003))
                                            ? VL_ULL(0xffffffffffffffff)
                                            : VL_ULL(0xffffffff))
                                        : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh400003))
                                            ? VL_ULL(0xffff)
                                            : VL_ULL(0xff))));
    VL_SHIFTL_WWI(512,512,9, __Vtemp6567, __Vtemp6566, 
                  (0x1f8U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__addr___05Fh399391 
                             << 3U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0U] 
        = __Vtemp6567[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[1U] 
        = __Vtemp6567[1U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[2U] 
        = __Vtemp6567[2U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[3U] 
        = __Vtemp6567[3U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[4U] 
        = __Vtemp6567[4U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[5U] 
        = __Vtemp6567[5U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[6U] 
        = __Vtemp6567[6U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[7U] 
        = __Vtemp6567[7U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[8U] 
        = __Vtemp6567[8U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[9U] 
        = __Vtemp6567[9U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xaU] 
        = __Vtemp6567[0xaU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xbU] 
        = __Vtemp6567[0xbU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xcU] 
        = __Vtemp6567[0xcU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xdU] 
        = __Vtemp6567[0xdU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xeU] 
        = __Vtemp6567[0xeU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xfU] 
        = __Vtemp6567[0xfU];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_fbindex_0_125_store_fbindex_1_12_ETC___05F_d3130 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390) 
           == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_fb_fillindex__DOT__data0_reg));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_epoch_0_099_store_epoch_1_100_10_ETC___05F_d3103 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__epoch___05Fh399395) 
           == ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_initiate_store_whas) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_epoch)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_whas___05F4_AND_rx_w_data_wget___05F5_BITS_1_ETC___05F_d249 
        = (((1U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                          >> 7U))) & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated_EN 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__CAN_FIRE_RL_instruction_commit) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_epoch_08_EQ_IF_rx_w_data_whas___05F4_THEN_rx_w___05FETC___05F_d111)) 
            & (1U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                            >> 7U)))) & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated) 
                                          | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107)) 
                                         & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__io_xactor_f_wr_resp__DOT__empty_reg) 
                                            | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_whas 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__CAN_FIRE_RL_instruction_commit) 
           & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_epoch_08_EQ_IF_rx_w_data_whas___05F4_THEN_rx_w___05FETC___05F_d111) 
               & (0U != (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                               >> 7U)))) & (((1U == 
                                              (3U & 
                                               (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                                >> 7U))) 
                                             & (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated)) 
                                                 & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107))) 
                                                | (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated) 
                                                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__io_xactor_f_wr_resp__DOT__empty_reg)) 
                                                   & (0U 
                                                      == 
                                                      (3U 
                                                       & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__io_xactor_f_wr_resp__DOT__data0_reg) 
                                                          >> 4U)))))) 
                                            | ((1U 
                                                != 
                                                (3U 
                                                 & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                                    >> 7U))) 
                                               & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_whas___05F4_AND_NOT_rx_w_data_wget___05F5_BI_ETC___05F_d103) 
                                                  | (2U 
                                                     == 
                                                     (3U 
                                                      & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                                         >> 7U))))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rxinst_w_ena_whas 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__CAN_FIRE_RL_instruction_commit) 
           & ((((0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                              >> 7U))) | ((1U == (3U 
                                                  & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                                     >> 7U))) 
                                          & (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated)) 
                                              & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107))) 
                                             | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_store_initiated) 
                                                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__io_xactor_f_wr_resp__DOT__empty_reg))))) 
               | ((1U != (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                >> 7U))) & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_whas___05F4_AND_NOT_rx_w_data_wget___05F5_BI_ETC___05F_d103) 
                                            | (2U == 
                                               (3U 
                                                & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rx_w_data_wget[4U] 
                                                   >> 7U)))))) 
              | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rg_epoch_08_EQ_IF_rx_w_data_whas___05F4_THEN_rx_w___05FETC___05F_d111))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__temp___05Fh295518 
        = (((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295609))
             ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295609))
                 ? VL_ULL(0xffffffffffffffff) : VL_ULL(0xffffffff))
             : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295609))
                 ? VL_ULL(0xffff) : VL_ULL(0xff))) 
           << (0x38U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x___05Fh295470 
                        << 3U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rg_eEpoch_read___05F01_CONCAT_rg_wEpoch_02_03_EQ_I_ETC___05F_d204)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__NOT_IF_fwding_read_rs1_93_BIT_64_94_AND_fwding_ETC___05F_d295));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rxinst_w_ena_whas 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__NOT_IF_fwding_read_rs1_93_BIT_64_94_AND_fwding_ETC___05F_d295) 
              | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rg_eEpoch_read___05F01_CONCAT_rg_wEpoch_02_03_EQ_I_ETC___05F_d204))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_1) 
            & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu_mv_delayed_output[0U] 
               >> 5U)) | (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2) 
                             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rg_eEpoch_read___05F01_CONCAT_rg_wEpoch_02_03_EQ_I_ETC___05F_d204)) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__NOT_IF_fwding_read_rs1_93_BIT_64_94_AND_fwding_ETC___05F_d295)) 
                           & (9U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509))) 
                          & (8U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu_EN_ma_inputs 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rg_eEpoch_read___05F01_CONCAT_rg_wEpoch_02_03_EQ_I_ETC___05F_d204)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__NOT_IF_fwding_read_rs1_93_BIT_64_94_AND_fwding_ETC___05F_d295)) 
           & ((9U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509)) 
              | (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_RDY_core_req_put 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_ff_core_response_rv_port0___05Fread___05F9_BIT_72___05FETC___05F_d3029) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__full_reg));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__v___05Fh101637 
        = ((0xfU == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640))
            ? (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__SEL_ARR_replacement_v_count_0_122_replacement___05FETC___05F_d1187)
            : ((8U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640))
                ? ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640))
                    ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640))
                        ? 0U : 1U) : 2U) : 3U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_rg_valid_0_79_rg_valid_1_80_rg_valid_2_ETC___05F_d2694 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__valid___05Fh375917) 
            >> (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__v___05Fh375911)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__y___05Fh378534));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0U] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0U]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0U]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[1U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[1U] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[1U]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[1U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[1U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[1U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[1U]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[1U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[1U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[1U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[1U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[2U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[2U] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[2U]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[2U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[2U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[2U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[2U]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[2U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[2U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[2U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[2U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[3U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[3U] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[3U]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[3U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[3U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[3U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[3U]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[3U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[3U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[3U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[3U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[4U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[4U] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[4U]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[4U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[4U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[4U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[4U]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[4U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[4U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[4U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[4U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[5U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[5U] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[5U]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[5U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[5U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[5U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[5U]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[5U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[5U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[5U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[5U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[6U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[6U] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[6U]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[6U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[6U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[6U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[6U]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[6U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[6U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[6U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[6U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[7U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[7U] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[7U]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[7U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[7U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[7U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[7U]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[7U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[7U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[7U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[7U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[8U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[8U] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[8U]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[8U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[8U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[8U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[8U]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[8U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[8U])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[8U]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[8U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[9U] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[9U] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[9U]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[9U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[9U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[9U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[9U]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[9U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[9U])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[9U]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[9U])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xaU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xaU] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xaU]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xaU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xaU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xaU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xaU]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xaU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xaU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xaU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xaU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xbU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xbU] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xbU]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xbU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xbU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xbU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xbU]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xbU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xbU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xbU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xbU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xcU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xcU] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xcU]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xcU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xcU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xcU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xcU]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xcU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xcU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xcU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xcU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xdU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xdU] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xdU]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xdU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xdU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xdU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xdU]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xdU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xdU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xdU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xdU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xeU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xeU] 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098)) 
           | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xeU]) 
              & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                  ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xeU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xeU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xeU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xeU]))
                  : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                      ? ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xeU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xeU])
                      : ((1U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                          ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xeU]
                          : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xeU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__MUX_fb_dataline_0_write_1___05FVAL_1[0xfU] 
        = ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xfU] 
            & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_data_0_702_store_data_1_703_704___05FETC___05F_d3098 
                       >> 0x20U))) | ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__x_wget___05Fh23403[0xfU]) 
                                      & ((4U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                          ? ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_7[0xfU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_6[0xfU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_5[0xfU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_4[0xfU]))
                                          : ((2U & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                              ? ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_3[0xfU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_2[0xfU])
                                              : ((1U 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fbindex___05Fh399390))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_1[0xfU]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__fb_dataline_0[0xfU])))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_SEL_ARR_store_io_0_104_store_io_1_105_106___05FETC___05F_d3162 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107)) 
                 & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response)) 
                    | (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_fbindex_0_125_store_fbindex_1_12_ETC___05F_d3130)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_SEL_ARR_store_io_0_104_store_io_1_105_106___05FETC___05F_d3132 
        = (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_io_0_104_store_io_1_105_106_rg_s_ETC___05F_d3107)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__CAN_FIRE_RL_update_fb_with_memory_response)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_store_fbindex_0_125_store_fbindex_1_12_ETC___05F_d3130));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp3__DOT__rg_minstret_D_IN 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_whas) 
            & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp3__DOT__rg_ir)))
            ? (VL_ULL(1) + vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp3__DOT__rg_minstret)
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp3__DOT__x___05Fh4061);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[0U] 
        = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_wget[0U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[1U] 
        = vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_wget[1U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[2U] 
        = ((0xffffffc0U & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_whas) 
                            << 6U) & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_wget[2U])) 
           | (0x3fU & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_commit_wget[2U]));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_9 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_10 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4inst__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_6 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3common__DOT__full_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_8 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3inst__DOT__full_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas) 
           & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[0U] 
              >> 1U));
    __Vtemp6591[1U] = ((3U & ((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)
                                        ? (((QData)((IData)(
                                                            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[2U])) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(
                                                               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[1U])) 
                                               << 0x1eU) 
                                              | ((QData)((IData)(
                                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[0U])) 
                                                 >> 2U)))
                                        : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas)
                                            ? (((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[2U])) 
                                                << 0x3eU) 
                                               | (((QData)((IData)(
                                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[1U])) 
                                                   << 0x1eU) 
                                                  | ((QData)((IData)(
                                                                     vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[0U])) 
                                                     >> 2U)))
                                            : VL_ULL(0)))) 
                              >> 0x1eU)) | (0xfffffffcU 
                                            & ((IData)(
                                                       (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)
                                                          ? 
                                                         (((QData)((IData)(
                                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[2U])) 
                                                           << 0x3eU) 
                                                          | (((QData)((IData)(
                                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[1U])) 
                                                              << 0x1eU) 
                                                             | ((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[0U])) 
                                                                >> 2U)))
                                                          : 
                                                         ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas)
                                                           ? 
                                                          (((QData)((IData)(
                                                                            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[2U])) 
                                                            << 0x3eU) 
                                                           | (((QData)((IData)(
                                                                               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[1U])) 
                                                               << 0x1eU) 
                                                              | ((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[0U])) 
                                                                 >> 2U)))
                                                           : VL_ULL(0))) 
                                                        >> 0x20U)) 
                                               << 2U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0_ma_flush_fl[0U] 
        = ((0xfffffffcU & ((IData)(((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)
                                     ? (((QData)((IData)(
                                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[2U])) 
                                         << 0x3eU) 
                                        | (((QData)((IData)(
                                                            vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[1U])) 
                                            << 0x1eU) 
                                           | ((QData)((IData)(
                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[0U])) 
                                              >> 2U)))
                                     : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas)
                                         ? (((QData)((IData)(
                                                             vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[2U])) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[1U])) 
                                                << 0x1eU) 
                                               | ((QData)((IData)(
                                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[0U])) 
                                                  >> 2U)))
                                         : VL_ULL(0)))) 
                           << 2U)) | (3U & (VL_NEGATE_I((IData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst))) 
                                            & (VL_NEGATE_I((IData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_whas))) 
                                               & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[0U]))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0_ma_flush_fl[1U] 
        = __Vtemp6591[1U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0_ma_flush_fl[2U] 
        = (3U & ((IData)((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)
                            ? (((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[2U])) 
                                << 0x3eU) | (((QData)((IData)(
                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[1U])) 
                                              << 0x1eU) 
                                             | ((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__wr_flush_wget[0U])) 
                                                >> 2U)))
                            : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__txinst_w_ena_whas)
                                ? (((QData)((IData)(
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[2U])) 
                                    << 0x3eU) | (((QData)((IData)(
                                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[1U])) 
                                                  << 0x1eU) 
                                                 | ((QData)((IData)(
                                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fn_alu___05F_d364[0U])) 
                                                    >> 2U)))
                                : VL_ULL(0))) >> 0x20U)) 
                 >> 0x1eU));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_4 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_5 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_7 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type__DOT__full_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas));
    VL_EXTEND_WI(83,4, __Vtemp6592, (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__CASE_IF_tx_type_w_data_whas___05F27_THEN_IF_tx_typ_ETC___05Fq10) 
                                      << 1U) | (1U 
                                                & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[0U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U] 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas) 
            & (0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U] 
                            >> 0x11U)))) ? __Vtemp6592[0U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[1U] 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas) 
            & (0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U] 
                            >> 0x11U)))) ? __Vtemp6592[1U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas) 
            & (0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U] 
                            >> 0x11U)))) ? __Vtemp6592[2U]
            : ((0xfffe0000U & ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas) 
                                 & (1U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U] 
                                                 >> 0x11U))))
                                 ? 1U : (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_ena_whas) 
                                          & (2U == 
                                             (3U & 
                                              (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U] 
                                               >> 0x11U))))
                                          ? 2U : 3U)) 
                               << 0x11U)) | (0x1ffffU 
                                             & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__tx_type_w_data_wget[2U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__fpu_EN___05Fstart 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu_EN_ma_inputs) 
           & (8U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox_EN_ma_inputs 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu_EN_ma_inputs) 
           & (9U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_rx_meta_w_data_whas___05F9_THEN_rx_meta_w_da_ETC___05F_d509)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_RDY_core_req_put 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_RDY_core_req_put) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_RDY_core_request_put));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__MUX_rg_valid_0_write_1___05FVAL_1 
        = (0xfU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__valid___05Fh101640) 
                   | ((IData)(1U) << (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__imem__DOT__icache__DOT__v___05Fh101637))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2_EN_commit_rd 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__initialize)) 
                 & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[2U] 
                    >> 6U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4_FULL_N 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4__DOT__empty_reg)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_9)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4inst_FULL_N 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4inst__DOT__empty_reg)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_10)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d219 
        = ((7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_clear_stall_in_decode_stage 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_stall) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d205 
        = (((7U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
            & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst))) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_flush_stage0 
        = ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_initialize)) 
           & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst) 
              | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta_FULL_N 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta__DOT__empty_reg)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_3)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval_FULL_N 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval__DOT__empty_reg)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_4)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst_FULL_N 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst__DOT__empty_reg)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_5)));
    VL_EXTEND_WI(81,4, __Vtemp6600, ((0xeU & (((8U 
                                                & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U])
                                                ? (
                                                   (4U 
                                                    & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U])
                                                    ? 5U
                                                    : 
                                                   ((2U 
                                                     & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U])
                                                     ? 5U
                                                     : 
                                                    ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[1U] 
                                                      << 0x1fU) 
                                                     | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U] 
                                                        >> 1U))))
                                                : (
                                                   (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[1U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U] 
                                                      >> 1U))) 
                                              << 1U)) 
                                     | (1U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type_D_IN[0U] 
        = ((0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
                         >> 0x11U))) ? __Vtemp6600[0U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type_D_IN[1U] 
        = ((0U == (3U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
                         >> 0x11U))) ? __Vtemp6600[1U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type_D_IN[2U] 
        = ((0x60000U & (((0x40000U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U])
                          ? ((0x20000U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U])
                              ? 3U : (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
                                      >> 0x11U)) : 
                         (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
                          >> 0x11U)) << 0x11U)) | (0x1ffffU 
                                                   & ((0U 
                                                       == 
                                                       (3U 
                                                        & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U] 
                                                           >> 0x11U)))
                                                       ? 
                                                      __Vtemp6600[2U]
                                                       : 
                                                      vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_tx_type_to_stage4_enq_data[2U])));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox__DOT__mul___05FEN_ma_inputs 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox_EN_ma_inputs) 
           & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rx_meta_w_data_wget[1U] 
                 >> 2U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox__DOT__div___05FEN_ma_inputs 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox_EN_ma_inputs) 
           & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__rx_meta_w_data_wget[1U] 
              >> 2U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_RDY_core_req_put) 
           & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__MUX_rg_stall_write_1___05FPSEL_2) 
               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__fwding_read_rs1_93_BIT_64_94_AND_fwding_read_r_ETC___05F_d228)) 
              & (1U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__IF_IF_IF_rx_meta_w_data_whas___05F9_THEN_IF_rx_met_ETC___05F_d246))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__MUX_floating_rf_upd_1___05FSEL_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2_EN_commit_rd) 
           & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__MUX_integer_rf_upd_1___05FSEL_3 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2_EN_commit_rd) 
            & (~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[0U])) 
           & (0U != (0x1fU & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_commit_rd[2U] 
                              >> 1U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage4__DOT__CAN_FIRE_RL_check_instruction 
        = (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3type__DOT__empty_reg) 
              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3common__DOT__empty_reg)) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4_FULL_N)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe4inst_FULL_N)) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe3inst__DOT__empty_reg));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_rerun_D_IN 
        = (1U & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_clear_stall_in_decode_stage)) 
                 & ((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_rerun)) 
                      & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[0U] 
                         >> 1U)) & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst))) 
                    & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_fence_port2___05Fread 
        = (1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_flush_stage0)
                  ? (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0_ma_flush_fl[0U] 
                     >> 1U) : ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__CAN_FIRE_RL_rl_gen_next_pc) 
                                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_fence))) 
                               & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_fence))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_sfence_port2___05Fread 
        = (1U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_flush_stage0)
                  ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0_ma_flush_fl[0U]
                  : ((~ ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__CAN_FIRE_RL_rl_gen_next_pc) 
                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_sfence))) 
                     & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage0__DOT__rg_sfence))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rxinst_w_ena_whas 
        = (((((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__empty_reg) 
                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1inst__DOT__empty_reg)) 
               & ((((((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__initialize)) 
                      & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__initialize))) 
                     & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__initialize))) 
                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta_FULL_N)) 
                   & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval_FULL_N)) 
                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst_FULL_N))) 
              & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_stall))) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__empty_reg)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval_FULL_N)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_wfi)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox__DOT__div___DOT__rg_count_EN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox__DOT__div___05FEN_ma_inputs) 
           | (0U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3__DOT__multicycle_alu__DOT__mbox__DOT__div___DOT__rg_count)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__WILL_FIRE_RL_ptwalk_request_to_dcache 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_RDY_core_req_put) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__empty_reg)) 
           & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)
            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_memory_request_get[0U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__data0_reg[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[1U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)
            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_memory_request_get[1U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__data0_reg[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)
            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_memory_request_get[2U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__data0_reg[2U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)
            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_memory_request_get[3U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__data0_reg[3U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem)
            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_memory_request_get[4U]
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__ptwalk_ff_memory_req__DOT__data0_reg[4U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_1 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_2 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1inst__DOT__empty_reg) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rxinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas 
        = (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rxinst_w_ena_whas) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__eEpoch_read___05F87_CONCAT_wEpoch_read___05F88_89_EQ_I_ETC___05F_d192)) 
           & (7U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_wfi_EN 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rxinst_w_ena_whas) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__eEpoch_read___05F87_CONCAT_wEpoch_read___05F88_89_EQ_I_ETC___05F_d192)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d205)) 
           | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_wfi) 
              & (((0U != ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_meip) 
                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_meie)) 
                           << 0xbU) | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__wr_csr_misa_wget___05F2_BIT_18_3_AND_rg_soft_seip___05FETC___05F_d67) 
                                         & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_seie)) 
                                        << 9U) | ((
                                                   ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_mtip) 
                                                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_mtie)) 
                                                   << 7U) 
                                                  | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__wr_csr_misa_wget___05F2_BIT_18_3_AND_rg_stip_9___05F_d70) 
                                                       & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_stie)) 
                                                      << 5U) 
                                                     | ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_msip) 
                                                          & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_msie)) 
                                                         << 3U) 
                                                        | (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__wr_csr_misa_wget___05F2_BIT_18_3_AND_rg_ssip_2___05F_d73) 
                                                            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1__DOT__rg_ssie)) 
                                                           << 1U))))))) 
                  | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5_flush_fst)) 
                 | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage3_flush_from_exe_fst))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_EN_core_req_put 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__CAN_FIRE_RL_core_req_to_dmem) 
           | (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__WILL_FIRE_RL_ptwalk_request_to_dcache));
    __Vtemp6615[2U] = ((0xffffe000U & ((IData)((((QData)((IData)(
                                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                                 << 0x31U) 
                                                | (((QData)((IData)(
                                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                                    << 0x11U) 
                                                   | ((QData)((IData)(
                                                                      vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                      >> 0xfU)))) 
                                       << 0xdU)) | 
                       ((0x1000U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                    << 2U)) | ((0x800U 
                                                & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                   >> 3U)) 
                                               | ((0x600U 
                                                   & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                      << 1U)) 
                                                  | ((0x1c0U 
                                                      & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U] 
                                                          << 0x1bU) 
                                                         | (0x7ffffc0U 
                                                            & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                               >> 5U)))) 
                                                     | ((1U 
                                                         & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                            >> 2U)) 
                                                        | (0x3eU 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U] 
                                                               << 0x1eU) 
                                                              | (0x3ffffffeU 
                                                                 & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                                    >> 2U))))))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[0U] 
        = ((0xfffffffeU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[1U] 
                            << 0x1eU) | (0x3ffffffeU 
                                         & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                                            >> 2U)))) 
           | (1U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                    >> 1U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[1U] 
        = ((1U & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[1U] 
                  >> 2U)) | (0xfffffffeU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                             << 0x1eU) 
                                            | (0x3ffffffeU 
                                               & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[1U] 
                                                  >> 2U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[2U] 
        = __Vtemp6615[2U];
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[3U] 
        = ((0x1fffU & ((IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                 << 0x31U) | (((QData)((IData)(
                                                               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                               << 0x11U) 
                                              | ((QData)((IData)(
                                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                 >> 0xfU)))) 
                       >> 0x13U)) | (0xffffe000U & 
                                     ((IData)(((((QData)((IData)(
                                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                                 << 0x31U) 
                                                | (((QData)((IData)(
                                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                                    << 0x11U) 
                                                   | ((QData)((IData)(
                                                                      vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                      >> 0xfU))) 
                                               >> 0x20U)) 
                                      << 0xdU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_core_req_put[4U] 
        = (0x1fffU & ((IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                 << 0x31U) | (((QData)((IData)(
                                                               vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                               << 0x11U) 
                                              | ((QData)((IData)(
                                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                 >> 0xfU))) 
                               >> 0x20U)) >> 0x13U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
        = ((0xfffff800U & ((IData)((((QData)((IData)(
                                                     vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                     << 0x31U) | (((QData)((IData)(
                                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                                   << 0x11U) 
                                                  | ((QData)((IData)(
                                                                     vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                     >> 0xfU)))) 
                           << 0xbU)) | ((0x600U & (
                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                                                   << 1U)) 
                                        | ((0x1f8U 
                                            & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[1U] 
                                                << 0x1bU) 
                                               | (0x7fffff8U 
                                                  & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                                                     >> 5U)))) 
                                           | ((4U & 
                                               (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                                                << 2U)) 
                                              | ((2U 
                                                  & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U]) 
                                                 | (1U 
                                                    & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                                                       >> 2U)))))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
        = ((0x7ffU & ((IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                << 0x31U) | (((QData)((IData)(
                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                              << 0x11U) 
                                             | ((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                >> 0xfU)))) 
                      >> 0x15U)) | (0xfffff800U & ((IData)(
                                                           ((((QData)((IData)(
                                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                                              << 0x31U) 
                                                             | (((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                                                 << 0x11U) 
                                                                | ((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                                   >> 0xfU))) 
                                                            >> 0x20U)) 
                                                   << 0xbU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U] 
        = (0x7ffU & ((IData)(((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[4U])) 
                                << 0x31U) | (((QData)((IData)(
                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[3U])) 
                                              << 0x11U) 
                                             | ((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U])) 
                                                >> 0xfU))) 
                              >> 0x20U)) >> 0x15U));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_3 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_meta_FULL_N) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_5 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2inst_FULL_N) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__CAN_FIRE_RL_connect_ena_data_4 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe2_mtval_FULL_N) 
           & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3_port1___05Fread[0U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? ((0xffffffc0U & ((IData)(((0x20000U & 
                                         vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U])
                                         ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                        [(0x1fU & (
                                                   (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                    << 0xbU) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                      >> 0x15U)))]
                                         : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300)) 
                               << 6U)) | ((0x3eU & 
                                           ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                             << 0xaU) 
                                            | (0x3feU 
                                               & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                  >> 0x16U)))) 
                                          | (1U & (
                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                   >> 0x11U))))
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3_port1___05Fread[1U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? ((0x3fU & ((IData)(((0x20000U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U])
                                   ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                  [(0x1fU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                              << 0xbU) 
                                             | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                >> 0x15U)))]
                                   : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300)) 
                         >> 0x1aU)) | (0xffffffc0U 
                                       & ((IData)((
                                                   ((0x20000U 
                                                     & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U])
                                                     ? 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0xbU) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0x15U)))]
                                                     : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300) 
                                                   >> 0x20U)) 
                                          << 6U))) : 
           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3_port1___05Fread[2U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? (0x3fU & ((IData)((((0x20000U & vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U])
                                   ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                  [(0x1fU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                              << 0xbU) 
                                             | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                >> 0x15U)))]
                                   : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300) 
                                 >> 0x20U)) >> 0x1aU))
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op3[2U]);
    __Vtemp6619[0U] = ((0xfffffffcU & ((IData)((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_ETC___05F_d130) 
                                                 & (0U 
                                                    == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__value___05Fh3301)))
                                                 ? VL_ULL(0)
                                                 : 
                                                (((6U 
                                                   != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                  & (2U 
                                                     == 
                                                     (3U 
                                                      & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                          << 0xbU) 
                                                         | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                            >> 0x15U)))))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                 [(0x1fU 
                                                   & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                       << 0x17U) 
                                                      | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                         >> 9U)))]
                                                  : 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                 [(0x1fU 
                                                   & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                       << 0x17U) 
                                                      | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                         >> 9U)))]))) 
                                       << 2U)) | ((
                                                   (6U 
                                                    != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                   & (2U 
                                                      == 
                                                      (3U 
                                                       & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                           << 0xbU) 
                                                          | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                             >> 0x15U)))))
                                                   ? 2U
                                                   : 
                                                  ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_ETC___05F_d130)
                                                    ? 0U
                                                    : 1U)));
    __Vtemp6619[1U] = ((3U & ((IData)((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_ETC___05F_d130) 
                                        & (0U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__value___05Fh3301)))
                                        ? VL_ULL(0)
                                        : (((6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                            & (2U == 
                                               (3U 
                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                    << 0xbU) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                      >> 0x15U)))))
                                            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                           [(0x1fU 
                                             & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                 << 0x17U) 
                                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                   >> 9U)))]
                                            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                           [(0x1fU 
                                             & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                 << 0x17U) 
                                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                   >> 9U)))]))) 
                              >> 0x1eU)) | (0xfffffffcU 
                                            & ((IData)(
                                                       ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_ETC___05F_d130) 
                                                          & (0U 
                                                             == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__value___05Fh3301)))
                                                          ? VL_ULL(0)
                                                          : 
                                                         (((6U 
                                                            != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                           & (2U 
                                                              == 
                                                              (3U 
                                                               & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                   << 0xbU) 
                                                                  | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                     >> 0x15U)))))
                                                           ? 
                                                          vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                          [
                                                          (0x1fU 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                               << 0x17U) 
                                                              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                 >> 9U)))]
                                                           : 
                                                          vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                          [
                                                          (0x1fU 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                               << 0x17U) 
                                                              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                 >> 9U)))])) 
                                                        >> 0x20U)) 
                                               << 2U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1_port1___05Fread[0U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? __Vtemp6619[0U] : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1_port1___05Fread[1U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? __Vtemp6619[1U] : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1_port1___05Fread[2U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? ((0xfffffffcU & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__value___05Fh3301) 
                               << 2U)) | (3U & ((IData)(
                                                        ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_ETC___05F_d130) 
                                                           & (0U 
                                                              == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__value___05Fh3301)))
                                                           ? VL_ULL(0)
                                                           : 
                                                          (((6U 
                                                             != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                            & (2U 
                                                               == 
                                                               (3U 
                                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                    << 0xbU) 
                                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                      >> 0x15U)))))
                                                            ? 
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                           [
                                                           (0x1fU 
                                                            & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                                << 0x17U) 
                                                               | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                  >> 9U)))]
                                                            : 
                                                           vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                           [
                                                           (0x1fU 
                                                            & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                                << 0x17U) 
                                                               | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                  >> 9U)))])) 
                                                         >> 0x20U)) 
                                                >> 0x1eU)))
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op1[2U]);
    __Vtemp6622[0U] = ((0xfffffff8U & ((IData)(((((
                                                   ((6U 
                                                     != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                    & (4U 
                                                       != 
                                                       (7U 
                                                        & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                            << 0xeU) 
                                                           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                              >> 0x12U))))) 
                                                   & (0U 
                                                      != 
                                                      (7U 
                                                       & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                           << 0xeU) 
                                                          | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                             >> 0x12U))))) 
                                                  & (1U 
                                                     != 
                                                     (7U 
                                                      & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                          << 0xeU) 
                                                         | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                            >> 0x12U))))) 
                                                 & (2U 
                                                    != 
                                                    (7U 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                         << 0xeU) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                           >> 0x12U)))))
                                                 ? VL_ULL(2)
                                                 : 
                                                (((6U 
                                                   != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                  & (2U 
                                                     == 
                                                     (7U 
                                                      & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                          << 0xeU) 
                                                         | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                            >> 0x12U)))))
                                                  ? VL_ULL(4)
                                                  : 
                                                 (((6U 
                                                    != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                   & (1U 
                                                      == 
                                                      (7U 
                                                       & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                           << 0xeU) 
                                                          | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                             >> 0x12U)))))
                                                   ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300
                                                   : 
                                                  (((0U 
                                                     == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__x1_avValue_op_addr_rs2addr___05Fh3304)) 
                                                    & ((6U 
                                                        == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                       | (0U 
                                                          == 
                                                          (7U 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                               << 0xeU) 
                                                              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                 >> 0x12U))))))
                                                    ? VL_ULL(0)
                                                    : 
                                                   (((6U 
                                                      != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                     & (4U 
                                                        == 
                                                        (7U 
                                                         & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                             << 0xeU) 
                                                            | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                               >> 0x12U)))))
                                                     ? 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))]
                                                     : 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))])))))) 
                                       << 3U)) | ((
                                                   (6U 
                                                    != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                   & (4U 
                                                      == 
                                                      (7U 
                                                       & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                           << 0xeU) 
                                                          | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                             >> 0x12U)))))
                                                   ? 4U
                                                   : 
                                                  (((6U 
                                                     == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                            << 0xeU) 
                                                           | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                              >> 0x12U)))))
                                                    ? 0U
                                                    : 
                                                   (((1U 
                                                      == 
                                                      (7U 
                                                       & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                           << 0xeU) 
                                                          | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                             >> 0x12U)))) 
                                                     | (2U 
                                                        == 
                                                        (7U 
                                                         & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                             << 0xeU) 
                                                            | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                               >> 0x12U)))))
                                                     ? 
                                                    (7U 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                         << 0xeU) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                           >> 0x12U)))
                                                     : 3U))));
    __Vtemp6622[1U] = ((7U & ((IData)(((((((6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                           & (4U != 
                                              (7U & 
                                               ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                 << 0xeU) 
                                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                   >> 0x12U))))) 
                                          & (0U != 
                                             (7U & 
                                              ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                << 0xeU) 
                                               | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                  >> 0x12U))))) 
                                         & (1U != (7U 
                                                   & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                       << 0xeU) 
                                                      | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                         >> 0x12U))))) 
                                        & (2U != (7U 
                                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                      << 0xeU) 
                                                     | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                        >> 0x12U)))))
                                        ? VL_ULL(2)
                                        : (((6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                            & (2U == 
                                               (7U 
                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                    << 0xeU) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                      >> 0x12U)))))
                                            ? VL_ULL(4)
                                            : (((6U 
                                                 != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                & (1U 
                                                   == 
                                                   (7U 
                                                    & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                        << 0xeU) 
                                                       | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                          >> 0x12U)))))
                                                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300
                                                : (
                                                   ((0U 
                                                     == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__x1_avValue_op_addr_rs2addr___05Fh3304)) 
                                                    & ((6U 
                                                        == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                       | (0U 
                                                          == 
                                                          (7U 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                               << 0xeU) 
                                                              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                 >> 0x12U))))))
                                                    ? VL_ULL(0)
                                                    : 
                                                   (((6U 
                                                      != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                     & (4U 
                                                        == 
                                                        (7U 
                                                         & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                             << 0xeU) 
                                                            | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                               >> 0x12U)))))
                                                     ? 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))]
                                                     : 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))])))))) 
                              >> 0x1dU)) | (0xfffffff8U 
                                            & ((IData)(
                                                       (((((((6U 
                                                              != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                             & (4U 
                                                                != 
                                                                (7U 
                                                                 & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                     << 0xeU) 
                                                                    | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                       >> 0x12U))))) 
                                                            & (0U 
                                                               != 
                                                               (7U 
                                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                    << 0xeU) 
                                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                      >> 0x12U))))) 
                                                           & (1U 
                                                              != 
                                                              (7U 
                                                               & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                   << 0xeU) 
                                                                  | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                     >> 0x12U))))) 
                                                          & (2U 
                                                             != 
                                                             (7U 
                                                              & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                  << 0xeU) 
                                                                 | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                    >> 0x12U)))))
                                                          ? VL_ULL(2)
                                                          : 
                                                         (((6U 
                                                            != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                           & (2U 
                                                              == 
                                                              (7U 
                                                               & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                   << 0xeU) 
                                                                  | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                     >> 0x12U)))))
                                                           ? VL_ULL(4)
                                                           : 
                                                          (((6U 
                                                             != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                            & (1U 
                                                               == 
                                                               (7U 
                                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                    << 0xeU) 
                                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                      >> 0x12U)))))
                                                            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300
                                                            : 
                                                           (((0U 
                                                              == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__x1_avValue_op_addr_rs2addr___05Fh3304)) 
                                                             & ((6U 
                                                                 == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                                | (0U 
                                                                   == 
                                                                   (7U 
                                                                    & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                        << 0xeU) 
                                                                       | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                          >> 0x12U))))))
                                                             ? VL_ULL(0)
                                                             : 
                                                            (((6U 
                                                               != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                              & (4U 
                                                                 == 
                                                                 (7U 
                                                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                                      << 0xeU) 
                                                                     | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                        >> 0x12U)))))
                                                              ? 
                                                             vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                             [
                                                             (0x1fU 
                                                              & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                                  << 0x12U) 
                                                                 | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                    >> 0xeU)))]
                                                              : 
                                                             vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                             [
                                                             (0x1fU 
                                                              & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                                  << 0x12U) 
                                                                 | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                                    >> 0xeU)))]))))) 
                                                        >> 0x20U)) 
                                               << 3U)));
    __Vtemp6622[2U] = (7U & ((IData)((((((((6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                           & (4U != 
                                              (7U & 
                                               ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                 << 0xeU) 
                                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                   >> 0x12U))))) 
                                          & (0U != 
                                             (7U & 
                                              ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                << 0xeU) 
                                               | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                  >> 0x12U))))) 
                                         & (1U != (7U 
                                                   & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                       << 0xeU) 
                                                      | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                         >> 0x12U))))) 
                                        & (2U != (7U 
                                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                      << 0xeU) 
                                                     | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                        >> 0x12U)))))
                                        ? VL_ULL(2)
                                        : (((6U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                            & (2U == 
                                               (7U 
                                                & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                    << 0xeU) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                      >> 0x12U)))))
                                            ? VL_ULL(4)
                                            : (((6U 
                                                 != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                & (1U 
                                                   == 
                                                   (7U 
                                                    & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                        << 0xeU) 
                                                       | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                          >> 0x12U)))))
                                                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__SEXT_decoder_func_32_8_BITS_40_TO_9_99___05F_d300
                                                : (
                                                   ((0U 
                                                     == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__x1_avValue_op_addr_rs2addr___05Fh3304)) 
                                                    & ((6U 
                                                        == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                       | (0U 
                                                          == 
                                                          (7U 
                                                           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                               << 0xeU) 
                                                              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                                 >> 0x12U))))))
                                                    ? VL_ULL(0)
                                                    : 
                                                   (((6U 
                                                      != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__IF_rg_rerun_3_OR_chk_interrupt_8_BIT_0_9_OR_IF_ETC___05F_d90)) 
                                                     & (4U 
                                                        == 
                                                        (7U 
                                                         & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[2U] 
                                                             << 0xeU) 
                                                            | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__decoder_func_32___05F_d88[1U] 
                                                               >> 0x12U)))))
                                                     ? 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__floating_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))]
                                                     : 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__registerfile__DOT__integer_rf__DOT__arr
                                                    [
                                                    (0x1fU 
                                                     & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[2U] 
                                                         << 0x12U) 
                                                        | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__pipe1__DOT__data0_reg[1U] 
                                                           >> 0xeU)))]))))) 
                                      >> 0x20U)) >> 0x1dU));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2_port1___05Fread[0U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? __Vtemp6622[0U] : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2[0U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2_port1___05Fread[1U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? __Vtemp6622[1U] : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2[1U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2_port1___05Fread[2U] 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__txinst_w_ena_whas)
            ? ((0xfffffff8U & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__x1_avValue_op_addr_rs2addr___05Fh3304) 
                               << 3U)) | __Vtemp6622[2U])
            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage2__DOT__rg_op2[2U]);
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_EN_core_request_put 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_EN_core_req_put) 
           & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[2U] 
                 >> 0xaU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_EN_core_req_put 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_EN_core_req_put) 
           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
               >> 1U) | (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem_core_req_put[0U] 
                            >> 2U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_core_request_put_BIT_2_52_54_AND_wr_satp_w_ETC___05F_d273 
        = (1U & ((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                     >> 2U)) & (((0U == (0xfU & (IData)(
                                                        (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                                         >> 0x3cU)))) 
                                 | (3U == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__priv___05Fh2621))) 
                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                   >> 1U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299 
        = (1U & (((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[3U] 
                      >> 2U)) | (((0x7fc0000U | (0x3ffffU 
                                                 & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[2U] 
                                                     << 0x14U) 
                                                    | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[1U] 
                                                       >> 0xcU)))) 
                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                      << 9U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                >> 0x17U))) 
                                 != (0x7ffffffU & (
                                                   (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[3U] 
                                                    << 0x19U) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[2U] 
                                                      >> 7U))))) 
                 | (((0x1ffU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[2U] 
                                 << 2U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[1U] 
                                           >> 0x1eU))) 
                     != (0x1ffU & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                           >> 0x2cU)))) 
                    & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[3U] 
                          >> 7U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316 
        = (1U & (((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[3U] 
                      >> 2U)) | (((0x7fc0000U | (0x3ffffU 
                                                 & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[2U] 
                                                     << 0x14U) 
                                                    | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[1U] 
                                                       >> 0xcU)))) 
                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                      << 9U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                >> 0x17U))) 
                                 != (0x7ffffffU & (
                                                   (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[3U] 
                                                    << 0x19U) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[2U] 
                                                      >> 7U))))) 
                 | (((0x1ffU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[2U] 
                                 << 2U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[1U] 
                                           >> 0x1eU))) 
                     != (0x1ffU & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                           >> 0x2cU)))) 
                    & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[3U] 
                          >> 7U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334 
        = (1U & (((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[3U] 
                      >> 2U)) | (((0x7fc0000U | (0x3ffffU 
                                                 & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[2U] 
                                                     << 0x14U) 
                                                    | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[1U] 
                                                       >> 0xcU)))) 
                                  & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                      << 9U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                >> 0x17U))) 
                                 != (0x7ffffffU & (
                                                   (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[3U] 
                                                    << 0x19U) 
                                                   | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[2U] 
                                                      >> 7U))))) 
                 | (((0x1ffU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[2U] 
                                 << 2U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[1U] 
                                           >> 0x1eU))) 
                     != (0x1ffU & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                           >> 0x2cU)))) 
                    & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[3U] 
                          >> 7U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_ENQ 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_EN_core_request_put) 
           & ((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U]) 
              | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                 >> 1U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__rg_tlb_miss_EN 
        = ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_EN_core_request_put) 
           & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
               | ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__rg_tlb_miss) 
                  & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                     >> 2U))) | ((((0U != (0xfU & (IData)(
                                                          (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                                           >> 0x3cU)))) 
                                   & (3U != (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__priv___05Fh2621))) 
                                  & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                        >> 1U))) & 
                                 (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                     >> 2U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__NOT_ff_core_request_notEmpty___05F576_577_AND_NOT___05FETC___05F_d2588 
        = (1U & (((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__ff_core_request__DOT__empty_reg)) 
                  & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache_EN_core_req_put))) 
                 & (~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dcache__DOT__SEL_ARR_fb_addr_0_read___05F315_fb_addr_1_read___05F31_ETC___05F_d2586))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__wr_count_misses_wget 
        = ((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
            & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334)) 
           & (((~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[3U] 
                   >> 2U)) | (((0x7fc0000U | (0x3ffffU 
                                              & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[2U] 
                                                  << 0x14U) 
                                                 | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[1U] 
                                                    >> 0xcU)))) 
                               & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                   << 9U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                             >> 0x17U))) 
                              != (0x7ffffffU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[3U] 
                                                 << 0x19U) 
                                                | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[2U] 
                                                   >> 7U))))) 
              | (((0x1ffU & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[2U] 
                              << 2U) | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[1U] 
                                        >> 0x1eU))) 
                  != (0x1ffU & (IData)((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                        >> 0x2cU)))) 
                 & (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[3U] 
                       >> 7U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__rg_tlb_miss_D_IN 
        = (((~ vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U]) 
            & ((~ (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__rg_tlb_miss)) 
               | (~ (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                     >> 2U)))) & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__wr_count_misses_wget));
    __Vtemp6634[5U] = ((0xfc000U & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_core_request_put_BIT_2_52_54_AND_wr_satp_w_ETC___05F_d273)
                                      ? ((0U == (3U 
                                                 & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                                     << 0x17U) 
                                                    | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                       >> 9U))))
                                          ? 5U : 7U)
                                      : ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                          << 0x1dU) 
                                         | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                            >> 3U))) 
                                    << 0xeU)) | ((0xffffe000U 
                                                  & ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__wr_count_misses_wget) 
                                                     << 0xdU)) 
                                                 | ((0x1000U 
                                                     & (((((0U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(
                                                                       (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__riscv__DOT__stage5__DOT__csr__DOT__csrfile__DOT__mk_grp1_mv_csr_satp 
                                                                        >> 0x3cU)))) 
                                                           | (3U 
                                                              == (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__priv___05Fh2621))) 
                                                          << 0xcU) 
                                                         | (0xfffff000U 
                                                            & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                               << 0xbU))) 
                                                        | (0xfffff000U 
                                                           & (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                                              << 0xaU)))) 
                                                    | (0xfffU 
                                                       & ((IData)(
                                                                  ((((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U])) 
                                                                     << 0x35U) 
                                                                    | (((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U])) 
                                                                        << 0x15U) 
                                                                       | ((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U])) 
                                                                          >> 0xbU))) 
                                                                   >> 0x20U)) 
                                                          >> 0x14U)))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[0U] 
        = ((0xfffffffcU & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                              & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                             & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                             ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[0U]
                             : (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                                 ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[0U]
                                 : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                                     ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[0U]
                                     : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[0U]))) 
                           << 2U)) | (3U & ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                             << 0x17U) 
                                            | (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                                               >> 9U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[1U] 
        = ((3U & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                     & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[0U]
                    : (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                        & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                        ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[0U]
                        : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[0U]
                            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[0U]))) 
                  >> 0x1eU)) | (0xfffffffcU & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                                                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                                                 ? 
                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[1U]
                                                 : 
                                                (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[1U]
                                                  : 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                                                   ? 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[1U]
                                                   : 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[1U]))) 
                                               << 2U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[2U] 
        = ((3U & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                     & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                    ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[1U]
                    : (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                        & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                        ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[1U]
                        : ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                            ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[1U]
                            : vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[1U]))) 
                  >> 0x1eU)) | (0xfffffffcU & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                                                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                                                 ? 
                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[2U]
                                                 : 
                                                (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[2U]
                                                  : 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                                                   ? 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[2U]
                                                   : 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[2U]))) 
                                               << 2U)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[3U] 
        = ((0xfffff000U & ((IData)((((QData)((IData)(
                                                     vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U])) 
                                     << 0x35U) | (((QData)((IData)(
                                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U])) 
                                                   << 0x15U) 
                                                  | ((QData)((IData)(
                                                                     vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U])) 
                                                     >> 0xbU)))) 
                           << 0xcU)) | ((3U & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                                                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                                                 ? 
                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[2U]
                                                 : 
                                                (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                  & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                                                  ? 
                                                 vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[2U]
                                                  : 
                                                 ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                                                   ? 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[2U]
                                                   : 
                                                  vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[2U]))) 
                                               >> 0x1eU)) 
                                        | (0xfffffffcU 
                                           & (((((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                 & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316)) 
                                                & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_2_18_BIT_98_19_20_OR_NOT_511_CON_ETC___05F_d334))
                                                ? vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_3[3U]
                                                : (
                                                   ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299) 
                                                    & (IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_1_00_BIT_98_01_02_OR_NOT_511_CON_ETC___05F_d316))
                                                    ? 
                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_2[3U]
                                                    : 
                                                   ((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_v_vpn_tag_0_81_BIT_98_82_83_OR_NOT_511_CON_ETC___05F_d299)
                                                     ? 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_1[3U]
                                                     : 
                                                    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__v_vpn_tag_0[3U]))) 
                                              << 2U))));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[4U] 
        = ((0xfffU & ((IData)((((QData)((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U])) 
                                << 0x35U) | (((QData)((IData)(
                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U])) 
                                              << 0x15U) 
                                             | ((QData)((IData)(
                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U])) 
                                                >> 0xbU)))) 
                      >> 0x14U)) | (0xfffff000U & ((IData)(
                                                           ((((QData)((IData)(
                                                                              vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U])) 
                                                              << 0x35U) 
                                                             | (((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U])) 
                                                                 << 0x15U) 
                                                                | ((QData)((IData)(
                                                                                vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U])) 
                                                                   >> 0xbU))) 
                                                            >> 0x20U)) 
                                                   << 0xcU)));
    vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__ff_lookup_result_D_IN[5U] 
        = ((0x100000U & (((IData)(vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb__DOT__NOT_core_request_put_BIT_2_52_54_AND_wr_satp_w_ETC___05F_d273)
                           ? (0U != ((vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[2U] 
                                      << 0x15U) | (
                                                   vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[1U] 
                                                   >> 0xbU)))
                           : (vlTOPp->mkTbSoc__DOT__soc__DOT__cclass__DOT__dmem__DOT__dtlb_core_request_put[0U] 
                              >> 2U)) << 0x14U)) | 
           __Vtemp6634[5U]);
}
