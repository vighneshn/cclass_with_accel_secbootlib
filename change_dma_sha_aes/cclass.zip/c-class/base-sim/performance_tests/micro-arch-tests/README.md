# Micro-Arch Tests

## Usgage

1. To run all tests:

```
make
```

2. To run a specific test:

```
make init
make <test-name>.riscv.out
```
