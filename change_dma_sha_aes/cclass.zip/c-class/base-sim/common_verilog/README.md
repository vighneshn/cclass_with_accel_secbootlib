# common_verilog

Contains basic common verilog modules used across the SHAKTI designs.